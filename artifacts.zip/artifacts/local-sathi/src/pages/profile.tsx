import { useEffect, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Camera, FileUp, Loader2, LogOut, ShieldAlert, BadgeCheck, RefreshCw } from 'lucide-react';
import { useGetAccount, getGetAccountQueryKey, useUploadMedia } from '@workspace/api-client-react';
import { useAuth } from '@/lib/auth';
import { useGeo } from '@/lib/geo';
import { useAct, errMsg, initials } from '@/lib/action';
import { PageHead } from '@/components/shell';
import { AuthNotice, ErrorBox } from '@/components/notices';
import { PostCard } from '@/components/post-card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

const LANGS = [
  ['en', 'English'], ['hi', 'हिन्दी'], ['gu', 'ગુજરાતી'], ['mr', 'मराठी'], ['ta', 'தமிழ்'],
  ['te', 'తెలుగు'], ['bn', 'বাংলা'], ['kn', 'ಕನ್ನಡ'], ['ml', 'മലയാളം'], ['pa', 'ਪੰਜਾਬੀ'],
];

function SelfieCam({ onCapture }: { onCapture: (b: Blob | null) => void }) {
  const video = useRef<HTMLVideoElement>(null);
  const stream = useRef<MediaStream | null>(null);
  const [on, setOn] = useState(false);
  const [shot, setShot] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const stop = () => {
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
    setOn(false);
  };
  useEffect(() => stop, []);
  const start = async () => {
    setErr(null);
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 640 }, audio: false });
      stream.current = s;
      setOn(true);
      setShot(null);
      onCapture(null);
      requestAnimationFrame(() => {
        if (video.current) {
          video.current.srcObject = s;
          void video.current.play();
        }
      });
    } catch {
      setErr('Camera unavailable or permission denied. Allow camera access and retry.');
    }
  };
  const capture = () => {
    const v = video.current;
    if (!v) return;
    const c = document.createElement('canvas');
    c.width = v.videoWidth;
    c.height = v.videoHeight;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    ctx.translate(c.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(v, 0, 0);
    setShot(c.toDataURL('image/jpeg', 0.85));
    c.toBlob((b) => onCapture(b), 'image/jpeg', 0.85);
    stop();
  };
  return (
    <div className="space-y-2">
      <div className="relative mx-auto grid aspect-square w-full max-w-[240px] place-items-center overflow-hidden rounded-full border-4 border-dashed border-accent bg-muted">
        {shot ? <img src={shot} alt="Selfie preview" className="h-full w-full object-cover" data-testid="img-selfie" /> : on ? <video ref={video} muted playsInline className="h-full w-full -scale-x-100 object-cover" data-testid="video-selfie" /> : <Camera className="h-10 w-10 text-muted-foreground" />}
        {on && <span className="absolute left-3 top-3 rounded-full bg-destructive px-2 py-0.5 font-data text-[10px] text-destructive-foreground">LIVE</span>}
      </div>
      {err && <p className="text-center text-xs text-destructive">{err}</p>}
      <div className="flex justify-center gap-2">
        {on ? (
          <Button onClick={capture} className="rounded-full" data-testid="button-capture-selfie">Capture</Button>
        ) : (
          <Button onClick={start} variant="outline" className="rounded-full" data-testid="button-start-camera">
            {shot ? <><RefreshCw className="h-4 w-4" /> Retake</> : <><Camera className="h-4 w-4" /> Start live camera</>}
          </Button>
        )}
      </div>
    </div>
  );
}

export default function ProfilePage() {
  const { authed, signOut, session } = useAuth();
  const { place, setRingtone } = useGeo();
  const account = useGetAccount({ query: { queryKey: getGetAccountQueryKey(), enabled: authed, refetchInterval: 10_000 } });
  const upload = useUploadMedia();
  const { act, pending } = useAct();
  const qc = useQueryClient();
  const { toast } = useToast();
  const p = account.data?.profile;
  const [form, setForm] = useState({ name: '', bio: '', city: '', state: '', area: '', language: 'hi', ringtone: true });
  const inited = useRef<string | null>(null);
  useEffect(() => {
    if (p && inited.current !== p.id) {
      inited.current = p.id;
      setForm({ name: p.name, bio: p.bio, city: p.city || place.city, state: p.state || place.state, area: p.area || place.area, language: p.language || 'hi', ringtone: p.ringtone });
    }
  }, [p, place.city, place.state, place.area]);
  const [aadhaar, setAadhaar] = useState<File | null>(null);
  const [selfie, setSelfie] = useState<Blob | null>(null);
  const [consent, setConsent] = useState(false);
  const [vBusy, setVBusy] = useState<string | null>(null);
  const [vMsg, setVMsg] = useState<string | null>(null);
  const [vErr, setVErr] = useState<string | null>(null);

  const save = async () => {
    try {
      const { name: _n, ...rest } = form;
      void _n;
      await act('updateProfile', rest);
      setRingtone(form.ringtone);
      void qc.invalidateQueries({ queryKey: getGetAccountQueryKey() });
      toast({ title: 'Profile saved' });
    } catch (e) {
      toast({ title: 'Save failed', description: errMsg(e), variant: 'destructive' });
    }
  };
  const verify = async () => {
    if (!aadhaar || !selfie) return;
    setVErr(null);
    try {
      setVBusy('Uploading document…');
      const a = await upload.mutateAsync({ data: { file: aadhaar, purpose: 'aadhaar' } });
      setVBusy('Uploading selfie…');
      const s = await upload.mutateAsync({ data: { file: new File([selfie], 'selfie.jpg', { type: 'image/jpeg' }), purpose: 'selfie' } });
      setVBusy('Running demo check…');
      const r = await act<{ status: string; message: string }>('mockVerify', { aadhaarPath: a.path, selfiePath: s.path, consent: true });
      setVMsg(r?.message || 'Demo verification complete.');
      setAadhaar(null);
      void qc.invalidateQueries({ queryKey: getGetAccountQueryKey() });
    } catch (e) {
      setVErr(errMsg(e));
    } finally {
      setVBusy(null);
    }
  };

  if (!authed)
    return (
      <div className="mx-auto max-w-3xl px-4 py-5 md:px-8 md:py-8">
        <PageHead kicker="Pehchaan · पहचान" title="Your profile" />
        <AuthNotice what="manage your profile" />
      </div>
    );

  return (
    <div className="mx-auto max-w-4xl px-4 py-5 md:px-8 md:py-8">
      <PageHead kicker="Pehchaan · पहचान" title="Your profile">
        <Button variant="outline" className="rounded-full" onClick={() => void signOut()} data-testid="button-signout"><LogOut className="h-4 w-4" /> Sign out</Button>
      </PageHead>
      {account.isLoading ? (
        <Skeleton className="h-72 rounded-3xl" />
      ) : account.isError ? (
        <ErrorBox message={errMsg(account.error)} onRetry={() => void account.refetch()} />
      ) : p && (
        <div className="space-y-6">
          <section className="rise relative overflow-hidden rounded-3xl bg-primary p-6 text-primary-foreground">
            <div className="toran absolute inset-x-0 top-0" />
            <div className="flex items-center gap-4">
              <span className="grid h-16 w-16 place-items-center rounded-2xl bg-accent font-display text-2xl font-extrabold text-accent-foreground">{initials(p.name)}</span>
              <div>
                <p className="font-display text-2xl font-bold" data-testid="text-profile-name">{p.name}</p>
                <p className="text-sm opacity-80">{session?.user?.email}</p>
                <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-primary-foreground/15 px-2 py-0.5 text-xs" data-testid="status-verification">
                  {p.verificationStatus === 'demo_verified' ? <><BadgeCheck className="h-3 w-3" /> Verified (demo) — not an identity guarantee</> : p.verificationStatus === 'verified' ? 'Verified' : 'Not verified'}
                </span>
              </div>
            </div>
          </section>

          <section className="grid gap-3 rounded-3xl border bg-card p-5 md:grid-cols-2">
            <h2 className="font-display text-xl font-semibold md:col-span-2">Account & settings</h2>
            <div><Input value={form.name} readOnly disabled className="rounded-xl" data-testid="input-name" /><p className="mt-1 text-[11px] text-muted-foreground">Name comes from your sign-in account.</p></div>
            <Select value={form.language} onValueChange={(v) => setForm({ ...form, language: v })}>
              <SelectTrigger className="rounded-xl" data-testid="select-language"><SelectValue /></SelectTrigger>
              <SelectContent>{LANGS.map(([k, l]) => <SelectItem key={k} value={k}>{l}</SelectItem>)}</SelectContent>
            </Select>
            <Textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder="अपने बारे में — Retired teacher, love gardening" className="rounded-xl md:col-span-2" data-testid="input-bio" />
            <Input value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} placeholder="इलाका / Area" className="rounded-xl" data-testid="input-area" />
            <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} placeholder="शहर / City" className="rounded-xl" data-testid="input-city" />
            <Input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} placeholder="राज्य / State" className="rounded-xl" data-testid="input-state" />
            <label className="flex items-center justify-between rounded-xl border px-3">
              <span className="text-sm">SOS ringtone</span>
              <Switch checked={form.ringtone} onCheckedChange={(v) => setForm({ ...form, ringtone: v })} data-testid="switch-profile-ringtone" />
            </label>
            <Button onClick={save} disabled={pending} className="rounded-full md:col-span-2" data-testid="button-save-profile">{pending && <Loader2 className="h-4 w-4 animate-spin" />} Save changes</Button>
          </section>

          <section className="rounded-3xl border bg-card p-5">
            <h2 className="font-display text-xl font-semibold">Demo identity check</h2>
            <div className="my-3 flex gap-2 rounded-2xl border border-destructive/30 bg-destructive/5 p-3 text-sm" data-testid="notice-demo-verify">
              <ShieldAlert className="h-5 w-5 shrink-0 text-destructive" />
              <p>This is a <b>mock</b> check for demonstration. Use a sample or masked document only — never your real Aadhaar number. It provides no actual identity guarantee, and the result shows as "Verified (demo)". Documents are stored privately and never broadcast.</p>
            </div>
            {vMsg ? (
              <p className="rounded-2xl bg-secondary/10 p-4 text-sm text-secondary" data-testid="text-verify-result">{vMsg}</p>
            ) : (
              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <p className="mb-2 text-sm font-semibold">1. Sample / masked Aadhaar</p>
                  <label className="flex h-40 cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed text-sm text-muted-foreground hover:border-primary/40">
                    <FileUp className="h-6 w-6" />
                    {aadhaar ? aadhaar.name : 'Choose image or PDF'}
                    <input type="file" accept="image/*,application/pdf" className="hidden" onChange={(e) => setAadhaar(e.target.files?.[0] ?? null)} data-testid="input-aadhaar" />
                  </label>
                </div>
                <div>
                  <p className="mb-2 text-sm font-semibold">2. Live selfie</p>
                  <SelfieCam onCapture={setSelfie} />
                </div>
                <label className="flex items-start gap-2 text-sm md:col-span-2">
                  <Checkbox checked={consent} onCheckedChange={(v) => setConsent(v === true)} className="mt-0.5" data-testid="checkbox-verify-consent" />
                  I understand this is a demo, I am using a sample/masked document, and I consent to private storage for this check.
                </label>
                {vErr && <p className="rounded-xl bg-destructive/10 p-3 text-sm text-destructive md:col-span-2">{vErr}</p>}
                <Button onClick={verify} disabled={!aadhaar || !selfie || !consent || !!vBusy} className="rounded-full md:col-span-2" data-testid="button-submit-verify">
                  {vBusy ? <><Loader2 className="h-4 w-4 animate-spin" /> {vBusy}</> : 'Run demo verification'}
                </Button>
              </div>
            )}
          </section>

          <section>
            <h2 className="mb-3 font-display text-xl font-semibold">Your posts</h2>
            {account.data!.posts.length === 0 ? (
              <p className="rounded-2xl border border-dashed p-6 text-center text-sm text-muted-foreground">You have not posted yet.</p>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {account.data!.posts.map((post, i) => <PostCard key={post.id} post={post} ownId={p.id} index={i} onChanged={() => void account.refetch()} />)}
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
}
