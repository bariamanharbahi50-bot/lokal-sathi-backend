import { useRef, useState } from 'react';
import { Plus, Search, Radio } from 'lucide-react';
import { useGetAccount, getGetAccountQueryKey } from '@workspace/api-client-react';
import { useAuth } from '@/lib/auth';
import { useGeo } from '@/lib/geo';
import { useFeed, SOURCE_LABEL } from '@/lib/feed';
import { CATEGORIES, IMAGES } from '@/lib/action';
import { PostCard, PostSkeleton } from '@/components/post-card';
import { CreatePostDialog } from '@/components/create-post';
import { LocationFilter } from '@/components/location-filter';
import { AuthNotice, LocationNotice, EmptyArt, ErrorBox } from '@/components/notices';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export default function FeedPage() {
  const { authed } = useAuth();
  const { fix, place } = useGeo();
  const { toast } = useToast();
  const [category, setCategory] = useState('all');
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [creating, setCreating] = useState(false);
  const feed = useFeed({ category, search });
  const account = useGetAccount({ query: { queryKey: getGetAccountQueryKey(), enabled: authed } });

  const onSearch = (v: string) => {
    setSearchInput(v);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setSearch(v.trim()), 450);
  };

  const openCreate = () => {
    if (!authed) {
      toast({ title: 'Sign in to post', description: 'Only signed-in neighbours can post.' });
      return;
    }
    if (!fix) {
      toast({ title: 'Share your location first', description: 'Posts need a fresh GPS reading within 1 km accuracy.' });
      return;
    }
    setCreating(true);
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-5 md:px-8 md:py-8">
      <section className="rise relative mb-6 overflow-hidden rounded-[2rem] bg-primary text-primary-foreground">
        <img src={IMAGES.moment} alt="" className="absolute inset-0 h-full w-full object-cover opacity-35 mix-blend-luminosity" />
        <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/85 to-transparent" />
        <div className="relative p-6 md:p-10">
          <p className="font-data text-[11px] uppercase tracking-[0.3em] text-accent">{place.area || place.city} · {new Date().toLocaleDateString('en-IN', { weekday: 'long' })}</p>
          <h1 className="mt-2 max-w-md font-display text-4xl font-extrabold leading-[1.02] md:text-5xl">
            Kya chal raha hai <span className="text-accent">pados</span> mein?
          </h1>
          <p className="mt-3 max-w-sm text-sm opacity-85">Chai stalls, lost keys, Sunday markets and the aunty who makes the best thepla. All within 5 km.</p>
          <button onClick={openCreate} data-testid="button-create-post" className="mt-5 inline-flex items-center gap-2 rounded-full bg-accent px-5 py-3 font-semibold text-accent-foreground transition hover:-translate-y-0.5">
            <Plus className="h-5 w-5" /> Share a moment
          </button>
        </div>
        <div className="toran absolute inset-x-0 bottom-0" />
      </section>

      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        <div className="min-w-0 space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <LocationFilter />
            <label className="relative min-w-[200px] flex-1">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input value={searchInput} onChange={(e) => onSearch(e.target.value)} placeholder="खोजें… samosa, plumber, garba" className="w-full rounded-full border bg-card py-2.5 pl-10 pr-4 text-sm outline-none focus:border-primary/50" data-testid="input-search" />
            </label>
          </div>
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4">
            {[{ id: 'all', label: 'Sab kuch', local: '' }, ...CATEGORIES].map((c) => (
              <button key={c.id} onClick={() => setCategory(c.id)} data-testid={`chip-category-${c.id}`} className={cn('shrink-0 rounded-full border px-4 py-2 text-sm transition-all', category === c.id ? 'border-primary bg-primary text-primary-foreground shadow-md' : 'bg-card hover:border-primary/40')}>
                {c.label}
              </button>
            ))}
          </div>

          {!authed && <AuthNotice what="see live neighbours and post" />}
          {authed && <LocationNotice compact />}

          <div className="flex items-center gap-2 text-xs" data-testid="text-feed-source">
            <span className={cn('inline-flex items-center gap-1.5 rounded-full px-3 py-1 font-data uppercase tracking-wider', feed.source === 'nearby' ? 'bg-secondary text-secondary-foreground' : feed.sample ? 'bg-accent/40 text-primary' : 'bg-muted')}>
              {feed.source === 'nearby' && <Radio className="h-3 w-3" />}
              {feed.sample ? SOURCE_LABEL.demo : SOURCE_LABEL[feed.source]}
            </span>
            {feed.message && <span className="text-muted-foreground">{feed.message}</span>}
          </div>

          {feed.error ? (
            <ErrorBox message={feed.error} onRetry={feed.reload} />
          ) : feed.loading ? (
            <div className="space-y-4">
              <PostSkeleton />
              <PostSkeleton />
            </div>
          ) : feed.posts.length === 0 ? (
            <EmptyArt title="Abhi sannata hai" body={search || category !== 'all' ? 'No posts match these filters. Try another category or word.' : 'Nobody has posted near you yet. Be the first neighbour to say namaste.'}>
              <button onClick={openCreate} className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground" data-testid="button-empty-create">
                Write the first post
              </button>
            </EmptyArt>
          ) : (
            <div className="space-y-5">
              {feed.posts.map((p, i) => (
                <PostCard key={p.id} post={p} sample={feed.sample} ownId={account.data?.profile.id} onChanged={feed.reload} index={i} />
              ))}
            </div>
          )}
        </div>

        <aside className="hidden space-y-4 lg:block">
          <div className="sticky top-6 space-y-4">
            <div className="overflow-hidden rounded-3xl border bg-card">
              <img src={IMAGES.market} alt="" className="h-32 w-full object-cover" />
              <div className="p-4">
                <p className="font-display text-lg font-semibold">Chowk is open</p>
                <p className="mt-1 text-sm text-muted-foreground">Promote your dukaan to neighbours within 50 km from Rs 299.</p>
              </div>
            </div>
            <div className="rounded-3xl bg-sidebar p-4 text-sidebar-foreground">
              <p className="font-data text-[10px] uppercase tracking-widest text-sidebar-primary">Privacy</p>
              <p className="mt-1 text-sm opacity-85">GPS stays in memory on this device. Shared coordinates are encrypted in our database for nearby matching.</p>
            </div>
          </div>
        </aside>
      </div>

      <button onClick={openCreate} className="fixed bottom-24 right-5 z-30 grid h-14 w-14 place-items-center rounded-2xl bg-destructive text-destructive-foreground shadow-xl transition active:scale-90 md:hidden" data-testid="button-fab-create">
        <Plus className="h-6 w-6" />
      </button>
      {authed && <CreatePostDialog open={creating} onOpenChange={setCreating} onCreated={feed.reload} />}
    </div>
  );
}
