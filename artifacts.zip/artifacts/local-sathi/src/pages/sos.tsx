import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Phone, Siren, BellRing, BellOff, CheckCircle2, MapPin, Loader2 } from 'lucide-react';
import { getGetAccountQueryKey } from '@workspace/api-client-react';
import { useAuth } from '@/lib/auth';
import { useGeo } from '@/lib/geo';
import { useAct, errMsg, haversineKm } from '@/lib/action';
import { PageHead } from '@/components/shell';
import { AuthNotice, LocationNotice, EmptyArt } from '@/components/notices';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { ago } from '@/components/post-card';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export default function SosPage() {
  const { authed } = useAuth();
  const { fix, getFresh, alerts, alertsError, refreshAlerts, ringtone, setRingtone, testTone } = useGeo();
  const { act } = useAct();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [consent, setConsent] = useState(false);
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const ready = authed && !!fix && consent && !sending;

  const fire = async () => {
    if (!ready) return;
    setSending(true);
    try {
      const f = await getFresh();
      await act('createAlert', { ...f, message: message.trim() || 'Need urgent help near my location' });
      toast({ title: 'Alert broadcast', description: 'Neighbours with Local Sathi open nearby will see it. Dial 112 if in danger.' });
      setMessage('');
      await refreshAlerts();
    } catch (e) {
      toast({ title: 'Alert not sent', description: errMsg(e), variant: 'destructive' });
    } finally {
      setSending(false);
    }
  };
  const resolve = async (id: string) => {
    try {
      await act('resolveAlert', { id });
      toast({ title: 'Marked safe' });
      await refreshAlerts();
    } catch (e) {
      toast({ title: 'Could not resolve', description: errMsg(e), variant: 'destructive' });
    }
  };
  const toggleRing = async (on: boolean) => {
    setRingtone(on);
    if (on) testTone();
    if (authed) {
      try {
        await act('updateProfile', { ringtone: on });
        void qc.invalidateQueries({ queryKey: getGetAccountQueryKey() });
      } catch (e) {
        toast({ title: 'Saved on this device only', description: errMsg(e) });
      }
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-5 md:px-8 md:py-8">
      <PageHead kicker="Suraksha · सुरक्षा" title="Neighbourhood SOS" />
      <a href="tel:112" className="rise mb-5 flex items-center gap-4 rounded-3xl bg-destructive p-4 text-destructive-foreground" data-testid="link-call-112">
        <span className="grid h-12 w-12 place-items-center rounded-full bg-destructive-foreground/15"><Phone className="h-6 w-6" /></span>
        <span className="flex-1">
          <span className="block font-display text-xl font-bold">Real emergency? Call 112</span>
          <span className="block text-sm opacity-90">Local Sathi is not an emergency service. It only alerts neighbours who have the app open.</span>
        </span>
      </a>

      <div className="grid gap-6 md:grid-cols-[1fr_1fr]">
        <section className="space-y-4">
          {!authed && <AuthNotice what="broadcast or receive SOS alerts" />}
          {authed && <LocationNotice />}
          <div className="rounded-3xl border bg-card p-5">
            <div className="mb-4 rounded-2xl border border-destructive/30 bg-destructive/5 p-3 text-sm" data-testid="notice-sos-sharing">
              <b>Your exact GPS location and account name will be shared</b> with nearby users while the alert is active. Your Aadhaar or identity documents are never broadcast.
            </div>
            <Textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="क्या हुआ? / શું થયું? e.g. elderly neighbour fell, need help at gate 2" rows={2} className="rounded-xl" data-testid="input-sos-message" maxLength={200} />
            <label className="mt-3 flex items-start gap-2 text-sm">
              <Checkbox checked={consent} onCheckedChange={(v) => setConsent(v === true)} data-testid="checkbox-sos-consent" className="mt-0.5" />
              I consent to sharing my exact location with nearby neighbours for this alert.
            </label>
            <div className="mt-6 flex flex-col items-center">
              <button
                onClick={() => void fire()}
                disabled={!ready}
                data-testid="button-sos-broadcast"
                aria-label="Broadcast SOS to nearby users"
                className="relative grid h-40 w-40 select-none place-items-center rounded-full bg-destructive text-destructive-foreground shadow-[0_20px_50px_-15px_hsl(5_76%_49%/.7)] transition-transform active:scale-95 disabled:opacity-40"
              >
                {ready && <span className="pulse-ring absolute inset-0 rounded-full bg-destructive/40" />}
                <span className="relative flex flex-col items-center">
                  {sending ? <Loader2 className="h-10 w-10 animate-spin" /> : <Siren className="h-10 w-10" />}
                  <span className="mt-1 font-display text-lg font-bold">{sending ? 'Sending' : 'Send SOS'}</span>
                </span>
              </button>
              <p className="mt-3 text-center text-xs text-muted-foreground">{!authed ? 'Sign in required' : !fix ? 'Share live location first' : !consent ? 'Tick consent to arm the button' : 'Tap to broadcast immediately'}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 rounded-3xl border bg-card p-4">
            {ringtone ? <BellRing className="h-5 w-5 text-destructive" /> : <BellOff className="h-5 w-5 text-muted-foreground" />}
            <div className="flex-1">
              <p className="font-semibold">Alert ringtone</p>
              <p className="text-xs text-muted-foreground">Plays when a new nearby alert arrives while this app is open (after you have tapped the page once).</p>
            </div>
            <Switch checked={ringtone} onCheckedChange={(v) => void toggleRing(v)} data-testid="switch-ringtone" />
          </div>
        </section>

        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-xl font-semibold">Active nearby alerts</h2>
            {authed && fix && <span className="flex items-center gap-1.5 font-data text-[10px] uppercase tracking-widest text-secondary"><span className="h-2 w-2 animate-pulse rounded-full bg-secondary" /> Checking every 5s</span>}
          </div>
          {alertsError && <p className="mb-3 rounded-xl bg-destructive/10 p-3 text-sm text-destructive">{alertsError}</p>}
          {!authed || !fix ? (
            <EmptyArt title="Alerts need live location" body="Sign in and share location to receive alerts from neighbours. Nothing is shown here until then — we never fake activity." />
          ) : alerts.length === 0 ? (
            <EmptyArt title="Sab theek hai" body="No active alerts around you right now." />
          ) : (
            <div className="space-y-3">
              {alerts.map((a) => (
                <article key={a.id} className={cn('rise rounded-3xl border-2 bg-card p-4', a.isOwn ? 'border-accent' : 'border-destructive')} data-testid={`card-alert-${a.id}`}>
                  <div className="flex items-center gap-2">
                    <Siren className="h-5 w-5 text-destructive" />
                    <p className="flex-1 font-semibold">{a.isOwn ? 'Your alert' : a.name}</p>
                    <span className="font-data text-xs text-muted-foreground">{ago(a.createdAt)}</span>
                  </div>
                  <p className="mt-2 text-[15px]">{a.message}</p>
                  <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1 font-data"><MapPin className="h-3 w-3" />{haversineKm(fix, a).toFixed(2)} km away</span>
                    <span>Expires {ago(a.expiresAt)}</span>
                    {!a.isOwn && <a href={`https://www.google.com/maps?q=${a.lat},${a.lng}`} target="_blank" rel="noreferrer" className="font-semibold text-primary underline" data-testid={`link-alert-map-${a.id}`}>Open map</a>}
                    {a.isOwn && (
                      <button onClick={() => void resolve(a.id)} className="ml-auto flex items-center gap-1 rounded-full bg-secondary px-3 py-1.5 font-semibold text-secondary-foreground" data-testid={`button-resolve-${a.id}`}>
                        <CheckCircle2 className="h-4 w-4" /> I am safe
                      </button>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
