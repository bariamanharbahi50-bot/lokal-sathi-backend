import { useCallback, useRef } from 'react';
import { useSathiAction, type ActionInputOperation } from '@workspace/api-client-react';

export function errMsg(e: unknown): string {
  const err = e as { status?: number; data?: unknown; message?: string };
  const data = err?.data as { message?: string; error?: string } | null | undefined;
  const detail = (data && (data.message || data.error)) || '';
  if (err?.status === 401) return 'Your session has expired or you are not signed in. Please sign in again.';
  if (err?.status === 503) return `Service not ready — setup is still needed. ${detail}`.trim();
  if (err?.status === 429) return detail || 'Too many requests. Please wait and try again.';
  if (detail) return detail;
  return err?.message || 'Something went wrong. Please try again.';
}

export function useAct() {
  const m = useSathiAction();
  const ref = useRef(m.mutateAsync);
  ref.current = m.mutateAsync;
  const act = useCallback(async <T = unknown>(operation: ActionInputOperation, payload: Record<string, unknown>) => {
    const r = await ref.current({ data: { operation, payload } });
    if (!r || !r.success) throw new Error('The server could not complete this action.');
    return r.data as T;
  }, []);
  return { act, pending: m.isPending };
}

export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

export function initials(name?: string) {
  return (name || 'S')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');
}

const BASE = import.meta.env.BASE_URL;
export const IMAGES = {
  food: `${BASE}images/street-food.jpg`,
  market: `${BASE}images/market.jpg`,
  moment: `${BASE}images/community.jpg`,
  business: `${BASE}images/local-business.jpg`,
  help: `${BASE}images/help.jpg`,
  event: `${BASE}images/festival.jpg`,
  lost: `${BASE}images/help.jpg`,
} as const;

export const CATEGORIES = [
  { id: 'moment', label: 'Daily moment', local: 'रोज़ की बात' },
  { id: 'food', label: 'Street food', local: 'ખાણીપીણી' },
  { id: 'market', label: 'Market', local: 'बाज़ार' },
  { id: 'help', label: 'Need help', local: 'मदद' },
  { id: 'event', label: 'Events', local: 'ઉત્સવ' },
  { id: 'business', label: 'Local business', local: 'दुकान' },
  { id: 'lost', label: 'Lost & found', local: 'खोया-पाया' },
];

export function categoryImage(cat?: string) {
  const k = (cat || '').toLowerCase();
  const hit = (Object.keys(IMAGES) as (keyof typeof IMAGES)[]).find((key) => k.includes(key));
  return IMAGES[hit ?? 'moment'];
}

export function categoryLabel(cat?: string) {
  return CATEGORIES.find((c) => c.id === cat)?.label ?? cat ?? 'Moment';
}

const RING_KEY = 'sathi.ringtone';
export const prefs = {
  getRingtone: () => {
    try {
      return localStorage.getItem(RING_KEY) !== 'off';
    } catch {
      return true;
    }
  },
  setRingtone: (on: boolean) => {
    try {
      localStorage.setItem(RING_KEY, on ? 'on' : 'off');
    } catch {
      /* ignore */
    }
  },
};
