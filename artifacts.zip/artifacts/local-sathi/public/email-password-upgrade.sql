-- Upgrade an existing Local Sathi database to allow verified email/password users.
-- Run once as postgres after 001_local_sathi.sql in the same Supabase project.
begin;

create or replace function public.sathi_ready() returns boolean
language sql security definer set search_path = pg_catalog
as $$
  select to_regclass('sathi_private.location_key') is not null
    and to_regclass('sathi_private.supported_cities') is not null
    and to_regclass('sathi_private.profiles') is not null
    and to_regclass('sathi_private.posts') is not null
    and to_regprocedure('public.sathi_account()') is not null
    and to_regprocedure('public.sathi_feed(jsonb)') is not null
    and to_regprocedure('public.sathi_action(text,jsonb)') is not null
    and to_regprocedure('public.sathi_delete_post(uuid)') is not null
    and exists (select 1 from storage.buckets where id='sathi-media' and public=false)
    and exists (select 1 from storage.buckets where id='sathi-identity' and public=false)
$$;

create or replace function public.sathi_email_ready() returns boolean
language sql security definer set search_path = pg_catalog
as $$ select public.sathi_ready() and to_regprocedure('sathi_private.actor()') is not null $$;

revoke all on function public.sathi_ready() from public,anon,authenticated,service_role;
revoke all on function public.sathi_email_ready() from public,anon,authenticated,service_role;
grant execute on function public.sathi_ready() to anon,authenticated;
grant execute on function public.sathi_email_ready() to anon,authenticated;

create or replace function sathi_private.actor() returns uuid
language plpgsql security definer set search_path = pg_catalog, sathi_private
as $$
declare
  u uuid := auth.uid();
  primary_provider text := coalesce(auth.jwt()->'app_metadata'->>'provider','');
  identity_provider text;
  identity_data jsonb;
  display_name text;
  avatar_url text;
begin
  if u is null or primary_provider not in ('google','email') then
    raise exception 'Use a Local Sathi email/password or Google account' using errcode = 'P0001';
  end if;
  select i.provider,i.identity_data into identity_provider,identity_data
    from auth.identities i
    where i.user_id = u and i.provider in ('google','email')
    order by case when i.provider=primary_provider then 0 else 1 end
    limit 1;
  if identity_data is null then
    raise exception 'Sign-in identity missing' using errcode = 'P0001';
  end if;
  if identity_provider='email' then
    if not exists (select 1 from auth.users where id=u and email_confirmed_at is not null) then
      raise exception 'Confirm your email address before using Local Sathi' using errcode = 'P0001';
    end if;
    display_name := left(coalesce(nullif(trim(auth.jwt()->'user_metadata'->>'full_name'),''),
      nullif(trim(split_part(identity_data->>'email','@',1)),''),'Neighbour'),120);
    avatar_url := '';
  else
    display_name := left(coalesce(nullif(trim(identity_data->>'full_name'),''),
      nullif(trim(identity_data->>'name'),''),'Google user'),120);
    avatar_url := coalesce(identity_data->>'avatar_url',identity_data->>'picture','');
  end if;
  if avatar_url !~ '^https://[^[:space:]]+$' or length(avatar_url) > 2048 then avatar_url := ''; end if;
  insert into sathi_private.profiles(id,name,avatar) values (u,display_name,avatar_url)
    on conflict (id) do update set name=excluded.name, avatar=excluded.avatar
    where profiles.name is distinct from excluded.name or profiles.avatar is distinct from excluded.avatar;
  return u;
end $$;

drop policy if exists sathi_storage_guard on storage.objects;
create policy sathi_storage_guard on storage.objects as restrictive for all to anon,authenticated
using (bucket_id not in ('sathi-media','sathi-identity') or (
  auth.uid() is not null and coalesce(auth.jwt()->'app_metadata'->>'provider','') in ('google','email')
  and public.sathi_action('_storageRead',jsonb_build_object('bucket',bucket_id,'path',name))='true'::jsonb))
with check (bucket_id not in ('sathi-media','sathi-identity') or (
  auth.uid() is not null and coalesce(auth.jwt()->'app_metadata'->>'provider','') in ('google','email')
  and owner_id=auth.uid()::text
  and name ~ ('^'||auth.uid()::text||'/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.'
    ||case when bucket_id='sathi-identity' then '(jpg)$' else '(jpg|mp4)$' end)));

drop policy if exists sathi_storage_insert on storage.objects;
create policy sathi_storage_insert on storage.objects for insert to authenticated
with check (bucket_id in ('sathi-media','sathi-identity') and owner_id=auth.uid()::text
  and split_part(name,'/',1)=auth.uid()::text
  and coalesce(auth.jwt()->'app_metadata'->>'provider','') in ('google','email'));

notify pgrst, 'reload schema';
commit;