-- Upgrade an existing Local Sathi database to remove post media when its post is deleted.
-- Run once as postgres after the existing Local Sathi setup SQL in the same Supabase project.
begin;
set local role postgres;

create or replace function public.sathi_delete_post(p_post_id uuid) returns jsonb
language plpgsql security definer set search_path = pg_catalog, sathi_private
as $$
declare
  u uuid := sathi_private.actor();
  removed_media_path text;
begin
  delete from sathi_private.posts p
    where p.id=p_post_id and p.author_id=u
    returning p.media_path into removed_media_path;
  if not found then raise exception 'Post not found or not owned' using errcode = 'P0001'; end if;
  return jsonb_build_object('deleted',true,'mediaPath',coalesce(removed_media_path,''));
end $$;

revoke all on function public.sathi_delete_post(uuid) from public,anon,authenticated,service_role;
grant execute on function public.sathi_delete_post(uuid) to authenticated;

notify pgrst, 'reload schema';
commit;