import { useQueryClient } from '@tanstack/react-query';
import { CheckCircle2, CircleDashed, Download, RefreshCw } from 'lucide-react';
import { getGetSathiConfigQueryKey } from '@workspace/api-client-react';
import { useAuth } from '@/lib/auth';
import { PageHead } from '@/components/shell';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

function Status({ ok, label }: { ok: boolean; label: string }) {
  return (
    <div className={cn('flex items-center gap-3 rounded-2xl border p-4', ok ? 'border-secondary/40 bg-secondary/10' : 'bg-card')} data-testid={`status-${label.toLowerCase().replace(/\s/g, '-')}`}>
      {ok ? <CheckCircle2 className="h-5 w-5 text-secondary" /> : <CircleDashed className="h-5 w-5 text-destructive" />}
      <span className="flex-1 font-semibold">{label}</span>
      <span className="font-data text-xs uppercase">{ok ? 'Ready' : 'Pending'}</span>
    </div>
  );
}

export default function SetupPage() {
  const { config, configLoading, configError } = useAuth();
  const qc = useQueryClient();
  const redirect = typeof window !== 'undefined' ? window.location.origin + import.meta.env.BASE_URL : '';
  const steps = [
    { t: 'Download the setup / continuation SQL', b: 'The setup script fills missing Local Sathi tables, RPCs, policies and private buckets while preserving existing rows.' },
    { t: 'Run it in Supabase', b: 'Run it in the same Supabase project. It checks existing table columns and stops without committing if the partial schema is incompatible.' },
    { t: 'Enable email sign-in', b: 'In Authentication → Sign In / Providers → Email, enable Email and turn off Confirm email for immediate signup without an email link. Supabase then marks new accounts as confirmed; leaving it on requires users to confirm before using private features.' },
    { t: 'Allow the redirect URL', b: `Authentication → URL Configuration: add ${redirect} to Redirect URLs. Google sign-in is optional.` },
    { t: 'Refresh status', b: 'Press the button below. When Database and Email/password are ready, create an account or sign in.' },
  ];
  return (
    <div className="mx-auto max-w-3xl px-4 py-5 md:px-8 md:py-8">
      <PageHead kicker="Setup · तैयारी" title="Get Local Sathi running" />
      <p className="rise mb-5 text-muted-foreground">Until setup is complete, you can browse clearly labelled sample content. Sign-in, posting, chat and SOS stay off — nothing is faked.</p>
      <div className="mb-4 grid gap-3 sm:grid-cols-2">
        {configLoading ? (
          <div className="h-16 animate-pulse rounded-2xl bg-muted sm:col-span-2" />
        ) : configError ? (
          <p className="rounded-2xl bg-destructive/10 p-4 text-sm text-destructive sm:col-span-2">Could not reach the API server.</p>
        ) : (
          <>
            <Status ok={!!config?.databaseReady} label="Database" />
            <Status ok={!!config?.emailEnabled && !!config?.emailAuthReady} label="Email/password sign-in" />
          </>
        )}
      </div>
      {config?.setupMessage && <p className="mb-4 rounded-2xl bg-accent/20 p-4 text-sm" data-testid="text-setup-message">{config.setupMessage}</p>}
      <div className="mb-8 flex flex-wrap gap-3">
        <a href={`${import.meta.env.BASE_URL}setup.sql`} download className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 font-semibold text-primary-foreground" data-testid="link-download-sql">
          <Download className="h-4 w-4" /> Download setup / continuation SQL
        </a>
        <a href={`${import.meta.env.BASE_URL}email-password-upgrade.sql`} download className="inline-flex items-center gap-2 rounded-full border px-5 py-2.5 font-semibold" data-testid="link-download-email-upgrade">
          <Download className="h-4 w-4" /> Existing database: enable email accounts
        </a>
        <a href={`${import.meta.env.BASE_URL}post-media-upgrade.sql`} download className="inline-flex items-center gap-2 rounded-full border px-5 py-2.5 font-semibold" data-testid="link-download-post-media-upgrade">
          <Download className="h-4 w-4" /> Existing database: remove media when deleting posts
        </a>
        <Button variant="outline" className="rounded-full" onClick={() => void qc.invalidateQueries({ queryKey: getGetSathiConfigQueryKey() })} data-testid="button-refresh-status">
          <RefreshCw className="h-4 w-4" /> Refresh status
        </Button>
      </div>
      <ol className="space-y-3">
        {steps.map((s, i) => (
          <li key={s.t} className="rise flex gap-4 rounded-3xl border bg-card p-5" style={{ animationDelay: `${i * 70}ms` }}>
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-accent font-display text-lg font-extrabold text-accent-foreground">{i + 1}</span>
            <div>
              <p className="font-display text-lg font-semibold">{s.t}</p>
              <p className="break-words text-sm text-muted-foreground">{s.b}</p>
            </div>
          </li>
        ))}
      </ol>
      <p className="mt-4 text-xs text-muted-foreground">For an older or partial Local Sathi install, use the updated setup / continuation SQL above. It preserves existing rows and rolls back if existing columns do not match. Confirm email is a Supabase project setting; turn it off only if you want new accounts to skip the email link.</p>
      <p className="mt-6 text-xs text-muted-foreground">Payments run in simulation mode: test QR codes only, no real UPI funds are ever collected.</p>
    </div>
  );
}
