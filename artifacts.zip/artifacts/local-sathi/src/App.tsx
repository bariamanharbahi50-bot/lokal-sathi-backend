import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter, Link } from 'wouter';
import { AuthProvider, useAuth } from '@/lib/auth';
import { GeoProvider } from '@/lib/geo';
import { Shell } from '@/components/shell';
import FeedPage from '@/pages/feed';
import ReelsPage from '@/pages/reels';
import ChowkPage from '@/pages/chowk';
import MyAdsPage from '@/pages/my-ads';
import MessagesPage from '@/pages/messages';
import SosPage from '@/pages/sos';
import ProfilePage from '@/pages/profile';
import LoginPage from '@/pages/login';
import SetupPage from '@/pages/setup';

const queryClient = new QueryClient({ defaultOptions: { queries: { refetchOnWindowFocus: false, retry: 1 } } });

function OauthBanner() {
  const { oauthError, clearOauthError } = useAuth();
  const [loc] = useLocation();
  if (!oauthError || loc === '/login') return null;
  return (
    <div className="flex items-center gap-3 bg-destructive px-4 py-2 text-sm text-destructive-foreground md:pl-72" data-testid="banner-oauth-error">
      <span className="flex-1">Google sign-in failed: {oauthError}</span>
      <Link href="/login" className="font-semibold underline">Retry</Link>
      <button onClick={clearOauthError} className="opacity-80" data-testid="button-dismiss-oauth">Dismiss</button>
    </div>
  );
}

function Router() {
  return (
    <Shell>
      <OauthBanner />
      <RoutedErrorBoundary>
        <Switch>
          <Route path="/" component={FeedPage} />
          <Route path="/reels" component={ReelsPage} />
          <Route path="/chowk" component={ChowkPage} />
          <Route path="/my-ads" component={MyAdsPage} />
          <Route path="/messages" component={MessagesPage} />
          <Route path="/sos" component={SosPage} />
          <Route path="/profile" component={ProfilePage} />
          <Route path="/login" component={LoginPage} />
          <Route path="/setup" component={SetupPage} />
          <Route component={NotFound} />
        </Switch>
      </RoutedErrorBoundary>
    </Shell>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <GeoProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
              <Router />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </GeoProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
