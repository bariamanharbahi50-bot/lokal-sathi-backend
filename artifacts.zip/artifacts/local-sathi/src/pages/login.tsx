import { useMemo, useState } from 'react';
import { Link, Redirect } from 'wouter';
import { Loader2 } from 'lucide-react';
import { SiGoogle } from 'react-icons/si';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '@/lib/auth';
import { IMAGES } from '@/lib/action';
import { Logo } from '@/components/shell';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

export default function LoginPage() {
  const { authed, canSignIn, canUseEmailAuth, signIn, signInWithEmail, signUpWithEmail, config, configLoading, oauthError, clearOauthError } = useAuth();
  const [mode, setMode] = useState<'signIn' | 'signUp'>('signIn');
  const [busy, setBusy] = useState(false);
  const [busyGoogle, setBusyGoogle] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const schema = useMemo(() => z.object({
    fullName: z.string(),
    email: z.string().trim().email('Enter a valid email address.'),
    password: z.string().min(1, 'Enter your password.').max(72, 'Password is too long.'),
  }).superRefine((values, ctx) => {
    if (mode === 'signUp') {
      if (values.fullName.trim().length < 2) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['fullName'], message: 'Enter your name (at least 2 characters).' });
      }
      if (values.password.length < 8) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['password'], message: 'Use at least 8 characters for a new password.' });
      }
    }
  }), [mode]);
  const form = useForm<{ fullName: string; email: string; password: string }>({
    resolver: zodResolver(schema),
    defaultValues: { fullName: '', email: '', password: '' },
  });
  if (authed) return <Redirect to="/" />;
  const submit = async (values: { fullName: string; email: string; password: string }) => {
    setErr(null);
    setNotice(null);
    setBusy(true);
    try {
      const email = values.email.trim().toLowerCase();
      if (mode === 'signUp') {
        const result = await signUpWithEmail(values.fullName, email, values.password);
        setNotice(result.confirmationRequired
          ? 'Account created. Check your email for a confirmation link, then sign in here.'
          : 'Account created. You are signed in.');
      } else {
        await signInWithEmail(email, values.password);
      }
    } catch (e) {
      setErr((e as Error).message || (mode === 'signUp' ? 'Could not create your account.' : 'Could not sign in.'));
    } finally {
      setBusy(false);
    }
  };
  const googleSignIn = async () => {
    setErr(null);
    setNotice(null);
    clearOauthError();
    setBusyGoogle(true);
    try {
      await signIn();
    } catch (e) {
      setErr((e as Error).message || 'Could not start Google sign-in.');
      setBusyGoogle(false);
    }
  };
  const showSetup = !configLoading && (!config?.databaseReady || (!canUseEmailAuth && !config?.googleEnabled));
  return (
    <div className="grid min-h-[calc(100dvh-5rem)] md:min-h-[100dvh] md:grid-cols-2">
      <div className="relative hidden overflow-hidden md:block">
        <img src={IMAGES.event} alt="" className="kenburns h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[hsl(232_50%_10%/.9)] to-transparent" />
        <p className="absolute bottom-10 left-10 right-10 font-display text-4xl font-extrabold leading-tight text-[hsl(40_48%_95%)]">
          Har gali ki kahani.<br /><span className="text-accent">Har pados ka saath.</span>
        </p>
      </div>
      <div className="jaali flex items-center justify-center p-6">
        <div className="rise w-full max-w-sm rounded-[2rem] border bg-card p-7 shadow-xl">
          <Logo />
          <h1 className="mt-6 font-display text-3xl font-extrabold text-primary">Namaste, pados.</h1>
          <p className="mt-2 text-sm text-muted-foreground">Sign in to post, chat and get SOS alerts from real neighbours.</p>
          {(oauthError || err) && <p className="mt-4 rounded-xl bg-destructive/10 p-3 text-sm text-destructive" data-testid="text-login-error">Sign-in failed: {oauthError || err}</p>}
          {notice && <p className="mt-4 rounded-xl bg-secondary/10 p-3 text-sm text-secondary" data-testid="text-login-notice">{notice}</p>}
          {configLoading ? (
            <div className="mt-6 h-12 animate-pulse rounded-full bg-muted" />
          ) : showSetup ? (
            <div className="mt-6 rounded-2xl border border-dashed border-primary/30 bg-accent/15 p-4 text-sm" data-testid="notice-login-setup">
              <p className="font-semibold">Setup needed — sign-in is not available yet.</p>
              <p className="mt-1 text-muted-foreground">{config?.setupMessage || 'Complete the database setup and enable email or Google sign-in.'}</p>
              <Link href="/setup" className="mt-2 inline-block font-semibold text-primary underline" data-testid="link-login-setup">View setup steps</Link>
            </div>
          ) : (
            <div className="mt-6 space-y-4">
              {canUseEmailAuth && (
                <>
                  <div className="flex rounded-full bg-muted p-1" role="tablist" aria-label="Email account action">
                    <button type="button" role="tab" aria-selected={mode === 'signIn'} onClick={() => { setMode('signIn'); setErr(null); setNotice(null); form.clearErrors(); }} className={`min-h-11 flex-1 rounded-full px-3 text-sm font-semibold ${mode === 'signIn' ? 'bg-card shadow-sm' : 'text-muted-foreground'}`} data-testid="tab-email-signin">Sign in</button>
                    {config?.emailSignupEnabled && <button type="button" role="tab" aria-selected={mode === 'signUp'} onClick={() => { setMode('signUp'); setErr(null); setNotice(null); form.clearErrors(); }} className={`min-h-11 flex-1 rounded-full px-3 text-sm font-semibold ${mode === 'signUp' ? 'bg-card shadow-sm' : 'text-muted-foreground'}`} data-testid="tab-email-signup">Create account</button>}
                  </div>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(submit)} className="space-y-3" noValidate>
                      {mode === 'signUp' && (
                        <FormField control={form.control} name="fullName" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Your name</FormLabel>
                            <FormControl><Input {...field} autoComplete="name" maxLength={120} placeholder="Name neighbours will see" className="min-h-12 rounded-xl" data-testid="input-signup-name" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      )}
                      <FormField control={form.control} name="email" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl><Input {...field} type="email" inputMode="email" autoCapitalize="none" autoComplete="email" maxLength={254} placeholder="you@example.com" className="min-h-12 rounded-xl" data-testid="input-login-email" /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={form.control} name="password" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl><Input {...field} type="password" autoComplete={mode === 'signUp' ? 'new-password' : 'current-password'} maxLength={72} placeholder={mode === 'signUp' ? 'At least 8 characters' : 'Your password'} className="min-h-12 rounded-xl" data-testid="input-login-password" /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <Button type="submit" disabled={busy || !canSignIn} className="min-h-12 w-full rounded-full" data-testid="button-email-submit">
                        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                        {busy ? (mode === 'signUp' ? 'Creating account…' : 'Signing in…') : (mode === 'signUp' ? 'Create account' : 'Sign in with email')}
                      </Button>
                    </form>
                  </Form>
                  {mode === 'signUp' && <p className="text-xs text-muted-foreground">If email confirmation is enabled, check your inbox before signing in.</p>}
                  {!config?.emailSignupEnabled && <p className="text-xs text-muted-foreground">New account registration is disabled in Supabase. Existing accounts can still sign in.</p>}
                </>
              )}
              {canUseEmailAuth && config?.googleEnabled && <div className="flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />or<span className="h-px flex-1 bg-border" /></div>}
              {config?.googleEnabled && (
                <button onClick={() => void googleSignIn()} disabled={busyGoogle} className="flex min-h-12 w-full items-center justify-center gap-3 rounded-full border bg-card py-3 font-semibold transition hover:-translate-y-0.5 disabled:opacity-60" data-testid="button-google-signin">
                  {busyGoogle ? <Loader2 className="h-5 w-5 animate-spin" /> : <SiGoogle className="h-4 w-4" />} Continue with Google
                </button>
              )}
            </div>
          )}
          <Link href="/" className="mt-6 block text-center text-sm text-muted-foreground underline underline-offset-4" data-testid="link-explore">Keep exploring sample content</Link>
        </div>
      </div>
    </div>
  );
}
