import { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'wouter';
import QRCode from 'qrcode';
import { useQueryClient } from '@tanstack/react-query';
import { Download, Loader2, ShieldAlert, Smartphone, ImagePlus, CheckCircle2, FlaskConical } from 'lucide-react';
import { useGetAdPlans, getGetAdPlansQueryKey, useUploadMedia, getGetAccountQueryKey } from '@workspace/api-client-react';
import { useAuth } from '@/lib/auth';
import { useGeo } from '@/lib/geo';
import { useAct, errMsg, IMAGES } from '@/lib/action';
import { PageHead } from '@/components/shell';
import { AuthNotice, LocationNotice, ErrorBox } from '@/components/notices';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

type Checkout = { adId: string; price: number; qrData: string; upiIntent: null; simulated: true };
const REACH: Record<string, { name: string; sub: string; local: string }> = {
  local: { name: 'Local', sub: 'Neighbours within 50 km', local: 'आस-पास' },
  state: { name: 'State', sub: 'Your entire state', local: 'राज्य भर' },
  national: { name: 'National', sub: 'All of India', local: 'पूरा भारत' },
};
const inr = (n: number) => `Rs ${n.toLocaleString('en-IN')}`;

export default function ChowkPage() {
  const { authed } = useAuth();
  const { fix, getFresh, place: picked, placeIsDemo } = useGeo();
  const place = placeIsDemo ? { country: '', state: '', city: '', area: '' } : picked;
  const plans = useGetAdPlans({ query: { queryKey: getGetAdPlansQueryKey() } });
  const upload = useUploadMedia();
  const { act } = useAct();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [, nav] = useLocation();
  const days = useMemo(() => Array.from(new Set((plans.data ?? []).map((p) => p.days))).sort((a, b) => a - b), [plans.data]);
  const [day, setDay] = useState<number | null>(null);
  const [planId, setPlanId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [url, setUrl] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [checkout, setCheckout] = useState<Checkout | null>(null);
  const [qr, setQr] = useState<string | null>(null);
  const [paying, setPaying] = useState(false);
  const [paid, setPaid] = useState(false);

  const activeDay = day ?? days[0] ?? null;
  const visible = (plans.data ?? []).filter((p) => p.days === activeDay);
  const selected = plans.data?.find((p) => p.id === planId);

  useEffect(() => {
    if (!checkout) return setQr(null);
    QRCode.toDataURL(checkout.qrData, { margin: 1, width: 360, color: { dark: '#1d2457', light: '#fbf6ec' } })
      .then(setQr)
      .catch(() => setQr(null));
  }, [checkout]);

  const submit = async () => {
    setErr(null);
    if (!selected) return setErr('Pick a plan first.');
    try {
      new URL(url);
    } catch {
      return setErr('Enter a full website or WhatsApp link, starting with https://');
    }
    try {
      setBusy('Checking location…');
      const f = await getFresh();
      let mediaPath: string | undefined;
      if (file) {
        setBusy('Uploading creative…');
        mediaPath = (await upload.mutateAsync({ data: { file, purpose: 'post' } })).path;
      }
      setBusy('Creating campaign…');
      const r = await act<Checkout>('createAd', { planId: selected.id, title: title.trim(), description: desc.trim(), targetUrl: url.trim(), mediaPath, ...f, city: place.city, state: place.state });
      setPaid(false);
      setCheckout(r);
    } catch (e) {
      setErr(errMsg(e));
    } finally {
      setBusy(null);
    }
  };

  const simulate = async () => {
    if (!checkout) return;
    setPaying(true);
    try {
      await act('simulatePayment', { adId: checkout.adId });
      setPaid(true);
      void qc.invalidateQueries({ queryKey: getGetAccountQueryKey() });
      toast({ title: 'Campaign active (simulation)', description: 'No money moved. Counters are now live in My Ads.' });
    } catch (e) {
      toast({ title: 'Simulation failed', description: errMsg(e), variant: 'destructive' });
    } finally {
      setPaying(false);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-5 md:px-8 md:py-8">
      <PageHead kicker="Chowk · चौक" title="Put your dukaan on the map" />
      <div className="rise relative mb-6 overflow-hidden rounded-[2rem] border">
        <img src={IMAGES.business} alt="" className="h-44 w-full object-cover md:h-56" />
        <div className="absolute inset-0 bg-gradient-to-t from-[hsl(232_50%_10%/.85)] to-transparent" />
        <p className="absolute bottom-4 left-5 right-5 font-display text-2xl font-bold text-[hsl(40_48%_95%)] md:text-3xl">From the kirana next door to the tiffin service across town.</p>
      </div>

      <div className="mb-5 flex items-start gap-3 rounded-2xl border border-accent bg-accent/20 p-4 text-sm" data-testid="notice-payment-sim">
        <FlaskConical className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
        <p>
          <b>Payment simulation mode.</b> Checkout shows a test QR that cannot receive money. Do not attempt to pay. Campaigns activate only through the simulated bank webhook. One campaign per 24 hours.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <section>
          <h2 className="mb-3 font-display text-xl font-semibold">1. Choose duration & reach</h2>
          {plans.isLoading ? (
            <Skeleton className="h-60 rounded-3xl" />
          ) : plans.isError ? (
            <ErrorBox message={errMsg(plans.error)} onRetry={() => void plans.refetch()} />
          ) : (
            <>
              <div className="mb-4 inline-flex rounded-full border bg-card p-1">
                {days.map((d) => (
                  <button key={d} onClick={() => setDay(d)} data-testid={`button-days-${d}`} className={cn('rounded-full px-4 py-1.5 text-sm font-semibold transition', activeDay === d ? 'bg-primary text-primary-foreground' : 'text-muted-foreground')}>
                    {d} days
                  </button>
                ))}
              </div>
              <div className="space-y-3">
                {visible.map((p) => {
                  const r = REACH[p.reach];
                  return (
                    <button key={p.id} onClick={() => setPlanId(p.id)} data-testid={`card-plan-${p.id}`} className={cn('flex w-full items-center gap-4 rounded-2xl border-2 bg-card p-4 text-left transition hover:-translate-y-0.5', planId === p.id ? 'border-primary shadow-lg' : 'border-transparent')}>
                      <span className={cn('grid h-12 w-12 shrink-0 place-items-center rounded-xl font-display text-lg font-extrabold', p.reach === 'local' ? 'bg-secondary text-secondary-foreground' : p.reach === 'state' ? 'bg-accent text-accent-foreground' : 'bg-destructive text-destructive-foreground')}>
                        {p.reach[0].toUpperCase()}
                      </span>
                      <span className="flex-1">
                        <span className="block font-semibold">
                          {r?.name ?? p.label} <span className="text-sm font-normal text-muted-foreground">· {r?.local}</span>
                        </span>
                        <span className="block text-sm text-muted-foreground">{r?.sub ?? p.label}</span>
                      </span>
                      <span className="font-data text-lg font-semibold text-primary">{inr(p.price)}</span>
                    </button>
                  );
                })}
              </div>
            </>
          )}
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-xl font-semibold">2. Your campaign</h2>
          {!authed && <AuthNotice what="create a campaign" />}
          {authed && !fix && <LocationNotice />}
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="दुकान का नाम — Patel Farsan Mart" className="rounded-xl bg-card" data-testid="input-ad-title" maxLength={80} />
          <Textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="ઓફર લખો — Fresh khaman every morning, 10% off this week" rows={3} className="rounded-xl bg-card" data-testid="input-ad-desc" maxLength={300} />
          <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://wa.me/91..." className="rounded-xl bg-card" data-testid="input-ad-url" />
          <label className="flex cursor-pointer items-center gap-2 rounded-xl border-2 border-dashed p-3 text-sm text-muted-foreground hover:border-primary/40">
            <ImagePlus className="h-4 w-4" /> {file ? file.name : 'Optional photo or video'}
            <input type="file" accept="image/*,video/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] ?? null)} data-testid="input-ad-media" />
          </label>
          {err && <p className="rounded-xl bg-destructive/10 p-3 text-sm text-destructive" data-testid="text-ad-error">{err}</p>}
          <Button onClick={submit} disabled={!authed || !fix || !!busy || !planId || title.trim().length < 3 || desc.trim().length < 5} className="w-full rounded-full py-6 text-base" data-testid="button-create-ad">
            {busy ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> {busy}
              </>
            ) : selected ? (
              `Continue to checkout · ${inr(selected.price)}`
            ) : (
              'Pick a plan to continue'
            )}
          </Button>
        </section>
      </div>

      <Dialog open={!!checkout} onOpenChange={(o) => !o && setCheckout(null)}>
        <DialogContent className="max-h-[94dvh] overflow-y-auto rounded-3xl">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Checkout · simulation</DialogTitle>
            <DialogDescription>This QR holds a non-payable test reference and the exact price. No real UPI funds can be sent.</DialogDescription>
          </DialogHeader>
          {checkout && (
            <div className="space-y-4">
              <div className="relative mx-auto w-fit rounded-3xl border-2 border-dashed border-primary/30 bg-[#fbf6ec] p-4">
                {qr ? <img src={qr} alt="Test payment reference QR" className="h-56 w-56" data-testid="img-qr" /> : <Skeleton className="h-56 w-56" />}
                <span className="absolute -right-2 -top-2 rotate-6 rounded-md bg-destructive px-2 py-0.5 font-data text-[10px] uppercase text-destructive-foreground">Test only</span>
              </div>
              <div className="text-center">
                <p className="font-data text-3xl font-semibold text-primary" data-testid="text-checkout-price">{inr(checkout.price)}</p>
                <p className="font-data text-[11px] text-muted-foreground">Ref {checkout.adId}</p>
              </div>
              {qr && (
                <a href={qr} download={`local-sathi-test-${checkout.adId}.png`} className="flex items-center justify-center gap-2 rounded-full border py-2.5 text-sm font-semibold" data-testid="link-download-qr">
                  <Download className="h-4 w-4" /> Download test QR
                </a>
              )}
              <div>
                <Button disabled className="w-full rounded-full" variant="outline" data-testid="button-instant-pay">
                  <Smartphone className="h-4 w-4" /> Instant Pay via App
                </Button>
                <p className="mt-1 text-center text-xs text-muted-foreground">Disabled until a live merchant integration is connected.</p>
              </div>
              <div className="flex gap-2 rounded-2xl bg-muted p-3 text-xs">
                <ShieldAlert className="h-4 w-4 shrink-0 text-destructive" />
                Simulation mode: pressing the button below pretends the bank confirmed payment. Nothing is charged.
              </div>
              {paid ? (
                <Button className="w-full rounded-full bg-secondary py-6 text-secondary-foreground" onClick={() => nav('/my-ads')} data-testid="button-goto-myads">
                  <CheckCircle2 className="h-5 w-5" /> Active — open My Ads
                </Button>
              ) : (
                <Button onClick={simulate} disabled={paying} className="w-full rounded-full py-6" data-testid="button-simulate-webhook">
                  {paying && <Loader2 className="h-4 w-4 animate-spin" />} Simulate successful bank webhook
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
