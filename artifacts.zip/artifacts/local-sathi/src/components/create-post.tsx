import { useState } from 'react';
import { ImagePlus, Loader2, X } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { useUploadMedia, getGetAccountQueryKey } from '@workspace/api-client-react';
import { useGeo } from '@/lib/geo';
import { useAct, errMsg, CATEGORIES } from '@/lib/action';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export function CreatePostDialog({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (o: boolean) => void; onCreated: () => void }) {
  const { getFresh, place: picked, placeIsDemo } = useGeo();
  const place = placeIsDemo ? { country: '', state: '', city: '', area: '' } : picked;
  const { act } = useAct();
  const upload = useUploadMedia();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [caption, setCaption] = useState('');
  const [category, setCategory] = useState('moment');
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const preview = file ? URL.createObjectURL(file) : null;

  const submit = async () => {
    setErr(null);
    try {
      setBusy('Checking fresh location…');
      const f = await getFresh();
      let mediaPath: string | undefined;
      let mediaType: 'text' | 'image' | 'video' = 'text';
      if (file) {
        setBusy(file.type.startsWith('video') ? 'Uploading video (server converts to H.264)…' : 'Uploading photo…');
        const r = await upload.mutateAsync({ data: { file, purpose: 'post' } });
        mediaPath = r.path;
        mediaType = file.type.startsWith('video') ? 'video' : 'image';
      }
      setBusy('Posting to your mohalla…');
      await act('createPost', { caption: caption.trim(), category, mediaType, mediaPath, ...f, city: place.city, state: place.state, area: place.area });
      toast({ title: 'Posted', description: 'Neighbours within 5 km can see it now.' });
      setCaption('');
      setFile(null);
      void qc.invalidateQueries({ queryKey: getGetAccountQueryKey() });
      onCreated();
      onOpenChange(false);
    } catch (e) {
      setErr(errMsg(e));
    } finally {
      setBusy(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92dvh] overflow-y-auto rounded-3xl">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Mohalla ko batao</DialogTitle>
          <DialogDescription>
            Posting as {place.area || place.city || 'your current GPS region'}. Your exact GPS is used for the 5 km radius only.
          </DialogDescription>
        </DialogHeader>
        <Textarea value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="आज मोहल्ले में क्या हुआ? / આજે શું નવું છે?" rows={4} className="rounded-2xl text-base" data-testid="input-caption" maxLength={600} />
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button key={c.id} onClick={() => setCategory(c.id)} data-testid={`chip-create-${c.id}`} className={cn('rounded-full border px-3 py-1 text-sm transition', category === c.id ? 'border-primary bg-primary text-primary-foreground' : 'bg-card hover:border-primary/40')}>
              {c.label}
            </button>
          ))}
        </div>
        {preview ? (
          <div className="relative overflow-hidden rounded-2xl border">
            {file?.type.startsWith('video') ? <video src={preview} className="max-h-64 w-full object-cover" muted controls /> : <img src={preview} alt="" className="max-h-64 w-full object-cover" />}
            <button onClick={() => setFile(null)} className="absolute right-2 top-2 rounded-full bg-card/90 p-1.5" data-testid="button-remove-media">
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <label className="flex cursor-pointer items-center justify-center gap-2 rounded-2xl border-2 border-dashed py-6 text-sm text-muted-foreground transition hover:border-primary/40 hover:text-primary">
            <ImagePlus className="h-5 w-5" /> Add photo or short video
            <input type="file" accept="image/*,video/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] ?? null)} data-testid="input-media" />
          </label>
        )}
        {err && <p className="rounded-xl bg-destructive/10 p-3 text-sm text-destructive" data-testid="text-create-error">{err}</p>}
        <Button onClick={submit} disabled={!!busy || caption.trim().length < 2} className="rounded-full py-6 text-base" data-testid="button-submit-post">
          {busy ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> {busy}
            </>
          ) : (
            'Post to neighbours'
          )}
        </Button>
      </DialogContent>
    </Dialog>
  );
}
