import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { createClient, type Session, type SupabaseClient } from '@supabase/supabase-js';
import { App } from '@capacitor/app';
import { Browser } from '@capacitor/browser';
import { Capacitor } from '@capacitor/core';
import { useQueryClient } from '@tanstack/react-query';
import {
  setAuthTokenGetter,
  useGetSathiConfig,
  getGetSathiConfigQueryKey,
  type SathiConfig,
} from '@workspace/api-client-react';

let currentToken: string | null = null;
setAuthTokenGetter(() => currentToken);

type AuthCtx = {
  config?: SathiConfig;
  configLoading: boolean;
  configError: boolean;
  retryConfig: () => void;
  session: Session | null;
  userId: string | null;
  authed: boolean;
  authReady: boolean;
  setupNeeded: boolean;
  canSignIn: boolean;
  canUseEmailAuth: boolean;
  signIn: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (fullName: string, email: string, password: string) => Promise<{ confirmationRequired: boolean }>;
  signOut: () => Promise<void>;
  oauthError: string | null;
  clearOauthError: () => void;
};

const Ctx = createContext<AuthCtx | null>(null);
const NATIVE_AUTH_REDIRECT = 'localsathi://auth/callback';

export function AuthProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient();
  const cfg = useGetSathiConfig({ query: { queryKey: getGetSathiConfigQueryKey(), staleTime: 60_000, retry: 1 } });
  const config = cfg.data;
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [oauthError, setOauthError] = useState<string | null>(() => {
    if (typeof window === 'undefined') return null;
    const q = new URLSearchParams(window.location.search);
    const h = new URLSearchParams(window.location.hash.replace(/^#/, ''));
    const e = q.get('error_description') || h.get('error_description') || q.get('error') || h.get('error');
    return e ? decodeURIComponent(e.replace(/\+/g, ' ')) : null;
  });
  const lastUser = useRef<string | null | undefined>(undefined);

  const client: SupabaseClient | null = useMemo(() => {
    if (!config?.supabaseUrl || !config?.supabaseAnonKey) return null;
    try {
      return createClient(config.supabaseUrl, config.supabaseAnonKey, {
        auth: {
          storage: typeof window !== 'undefined'
            ? Capacitor.isNativePlatform() ? window.localStorage : window.sessionStorage
            : undefined,
          persistSession: true,
          detectSessionInUrl: !Capacitor.isNativePlatform(),
          autoRefreshToken: true,
        },
      });
    } catch {
      return null;
    }
  }, [config?.supabaseUrl, config?.supabaseAnonKey]);

  const applySession = useCallback(
    (s: Session | null) => {
      currentToken = s?.access_token ?? null;
      setSession(s);
      const uid = s?.user?.id ?? null;
      if (lastUser.current !== undefined && lastUser.current !== uid) {
        qc.removeQueries({ predicate: (q) => q.queryKey[0] !== '/api/sathi/config' });
      }
      lastUser.current = uid;
    },
    [qc],
  );

  useEffect(() => {
    if (cfg.isLoading) return;
    if (!client) {
      setAuthReady(true);
      return;
    }
    let alive = true;
    client.auth.getSession().then(({ data }) => {
      if (!alive) return;
      applySession(data.session);
      setAuthReady(true);
    });
    const { data: sub } = client.auth.onAuthStateChange((_e, s) => applySession(s));
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, [client, cfg.isLoading, applySession]);

  useEffect(() => {
    if (!client || !Capacitor.isNativePlatform()) return;
    let alive = true;
    const handleCallback = async (url: string) => {
      if (!url.startsWith(NATIVE_AUTH_REDIRECT)) return;
      await Browser.close().catch(() => undefined);
      const callback = new URL(url);
      const code = callback.searchParams.get('code');
      if (code) {
        const { error } = await client.auth.exchangeCodeForSession(code);
        if (error) setOauthError(error.message);
        return;
      }
      const fragment = new URLSearchParams(callback.hash.replace(/^#/, ''));
      const accessToken = fragment.get('access_token');
      const refreshToken = fragment.get('refresh_token');
      if (accessToken && refreshToken) {
        const { error } = await client.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken,
        });
        if (error) setOauthError(error.message);
      }
    };
    const listener = App.addListener('appUrlOpen', ({ url }) => {
      void handleCallback(url);
    });
    void App.getLaunchUrl().then((launch) => {
      if (alive && launch?.url) void handleCallback(launch.url);
    });
    return () => {
      alive = false;
      void listener.then((handle) => handle.remove());
    };
  }, [client]);

  const canUseEmailAuth = !!config?.emailEnabled && !!config.emailAuthReady;
  const setupNeeded = !config || !config.databaseReady || (!config.googleEnabled && !canUseEmailAuth) || !client;
  const canSignIn = !!client && !!config?.databaseReady && (!!config.googleEnabled || canUseEmailAuth);

  const signIn = useCallback(async () => {
    if (!client) throw new Error('Sign-in is not configured yet.');
    const native = Capacitor.isNativePlatform();
    const { data, error } = await client.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: native ? NATIVE_AUTH_REDIRECT : window.location.origin + import.meta.env.BASE_URL,
        skipBrowserRedirect: native,
      },
    });
    if (error) throw error;
    if (native && data.url) await Browser.open({ url: data.url });
  }, [client]);

  const signInWithEmail = useCallback(async (email: string, password: string) => {
    if (!client) throw new Error('Sign-in is not configured yet.');
    if (!config?.emailEnabled || !config.emailAuthReady) throw new Error('Finish the email/password setup steps before signing in.');
    const { error } = await client.auth.signInWithPassword({ email, password });
    if (error) throw error;
  }, [client, config?.emailEnabled, config?.emailAuthReady]);

  const signUpWithEmail = useCallback(async (fullName: string, email: string, password: string) => {
    if (!client) throw new Error('Sign-in is not configured yet.');
    if (!config?.emailEnabled || !config.emailSignupEnabled) throw new Error('Email account registration is not enabled yet.');
    const { data, error } = await client.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName.trim() },
        emailRedirectTo: Capacitor.isNativePlatform()
          ? NATIVE_AUTH_REDIRECT
          : window.location.origin + import.meta.env.BASE_URL,
      },
    });
    if (error) throw error;
    if (data.session) applySession(data.session);
    return { confirmationRequired: !data.session };
  }, [client, config?.emailEnabled, config?.emailSignupEnabled, applySession]);

  const signOut = useCallback(async () => {
    if (client) await client.auth.signOut();
    applySession(null);
  }, [client, applySession]);

  const value: AuthCtx = {
    config,
    configLoading: cfg.isLoading,
    configError: cfg.isError,
    retryConfig: () => void cfg.refetch(),
    session,
    userId: session?.user?.id ?? null,
    authed: !!session && !!config?.databaseReady,
    authReady,
    setupNeeded,
    canSignIn,
    canUseEmailAuth,
    signIn,
    signInWithEmail,
    signUpWithEmail,
    signOut,
    oauthError,
    clearOauthError: () => {
      setOauthError(null);
      window.history.replaceState(null, '', window.location.pathname);
    },
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useAuth outside provider');
  return c;
}
