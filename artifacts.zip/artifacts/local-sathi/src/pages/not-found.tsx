import { Link } from 'wouter';
import { EmptyArt } from '@/components/notices';

export default function NotFound() {
  return (
    <div className="mx-auto max-w-xl px-4 py-16">
      <EmptyArt title="Yeh gali nahi mili" body="This lane does not exist. Head back to your mohalla.">
        <Link href="/" className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground" data-testid="link-404-home">Back home</Link>
      </EmptyArt>
    </div>
  );
}
