-- Run as postgres in YOUR Supabase project's SQL editor.
-- This migration does not connect to, or modify, Replit's database.
-- Safe continuation for partial Local Sathi installs. It preserves existing rows,
-- fills missing objects, validates existing table columns, and replaces only the
-- named Sathi Storage policies. If validation fails, the transaction rolls back.
begin;
set local role postgres;
-- Remove only the Sathi-owned Storage policies and RPCs before recreating them.
-- PostgreSQL cannot rename input parameters with CREATE OR REPLACE.
drop policy if exists sathi_storage_guard on storage.objects;
drop policy if exists sathi_storage_insert on storage.objects;
drop policy if exists sathi_storage_select on storage.objects;
drop policy if exists sathi_storage_delete on storage.objects;
drop policy if exists sathi_storage_no_update on storage.objects;
drop policy if exists sathi_storage_delete_guard on storage.objects;
-- Remove the legacy Sathi update policy on the retired sathi_assets bucket.
drop policy if exists sathi_storage_update on storage.objects;
-- Recreate readiness RPCs so older jsonb/invoker definitions can be corrected.
drop function if exists public.sathi_email_ready();
drop function if exists public.sathi_ready();
drop function if exists public.sathi_feed(jsonb);
drop function if exists public.sathi_action(text,jsonb);
drop function if exists public.sathi_delete_post(uuid);
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;
create schema if not exists sathi_private authorization postgres;
revoke all on schema sathi_private from public, anon, authenticated, service_role;
alter default privileges in schema sathi_private revoke all on tables from public, anon, authenticated, service_role;
alter default privileges in schema sathi_private revoke execute on functions from public, anon, authenticated, service_role;

do $$
begin
  create type sathi_private.verification_status as enum ('unverified', 'demo_verified');
exception when duplicate_object then null;
end $$;
create table if not exists sathi_private.location_key (
  singleton boolean primary key default true check (singleton),
  secret text not null
);

-- Public geographic reference data only: never a user's plaintext coordinates.
create table if not exists sathi_private.supported_cities (
  city text not null,
  state text not null,
  centroid_lat double precision not null check (centroid_lat between -90 and 90),
  centroid_lng double precision not null check (centroid_lng between -180 and 180),
  primary key(city,state)
);
insert into sathi_private.supported_cities values
 ('Ahmedabad','Gujarat',23.0225,72.5714),('Surat','Gujarat',21.1702,72.8311),
 ('Vadodara','Gujarat',22.3072,73.1812),('Rajkot','Gujarat',22.3039,70.8022),
 ('Mumbai','Maharashtra',19.076,72.8777),('Pune','Maharashtra',18.5204,73.8567),
 ('Nagpur','Maharashtra',21.1458,79.0882),('Bengaluru','Karnataka',12.9716,77.5946),
 ('Mysuru','Karnataka',12.2958,76.6394),('New Delhi','Delhi',28.6139,77.209),
 ('Jaipur','Rajasthan',26.9124,75.7873),('Udaipur','Rajasthan',24.5854,73.7125),
 ('Chennai','Tamil Nadu',13.0827,80.2707),('Coimbatore','Tamil Nadu',11.0168,76.9558),
 ('Hyderabad','Telangana',17.385,78.4867),('Kolkata','West Bengal',22.5726,88.3639),
 ('Lucknow','Uttar Pradesh',26.8467,80.9462),('Noida','Uttar Pradesh',28.5355,77.391),
 ('Indore','Madhya Pradesh',22.7196,75.8577),('Bhopal','Madhya Pradesh',23.2599,77.4126),
 ('Kochi','Kerala',9.9312,76.2673),('Thiruvananthapuram','Kerala',8.5241,76.9366),
 ('Ludhiana','Punjab',30.901,75.8573),('Amritsar','Punjab',31.634,74.8723),
 ('Gurugram','Haryana',28.4595,77.0266),('Faridabad','Haryana',28.4089,77.3178),
 ('Patna','Bihar',25.5941,85.1376),('Bhubaneswar','Odisha',20.2961,85.8245),
 ('Guwahati','Assam',26.1445,91.7362)
on conflict (city,state) do nothing;

create table if not exists sathi_private.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null check (length(name) between 1 and 120),
  avatar text not null default '',
  bio text not null default '' check (length(bio) <= 500),
  city text not null default '' check (length(city) <= 100),
  state text not null default '' check (length(state) <= 100),
  area text not null default '' check (length(area) <= 100),
  language text not null default 'en' check (language in ('en','hi','gu','mr','ta','te','bn','kn','ml','pa')),
  ringtone boolean not null default true,
  verification_status sathi_private.verification_status not null default 'unverified',
  demo_consent_at timestamptz,
  created_at timestamptz not null default clock_timestamp()
);
create table if not exists sathi_private.heartbeats (
  user_id uuid primary key references sathi_private.profiles(id) on delete cascade,
  location_cipher bytea not null,
  captured_at timestamptz not null,
  updated_at timestamptz not null default clock_timestamp()
);
create table if not exists sathi_private.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references sathi_private.profiles(id) on delete cascade,
  caption text not null check (length(caption) <= 3000),
  category text not null check (length(category) between 1 and 60),
  media_type text not null check (media_type in ('text','image','video')),
  media_path text,
  location_cipher bytea not null,
  city text not null,
  state text not null,
  area text not null,
  created_at timestamptz not null default clock_timestamp(),
  check ((media_type = 'text' and media_path is null and length(trim(caption)) > 0)
     or (media_type <> 'text' and media_path is not null))
);
create table if not exists sathi_private.likes (
  post_id uuid references sathi_private.posts(id) on delete cascade,
  user_id uuid references sathi_private.profiles(id) on delete cascade,
  created_at timestamptz not null default clock_timestamp(),
  primary key(post_id,user_id)
);
create table if not exists sathi_private.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references sathi_private.posts(id) on delete cascade,
  user_id uuid not null references sathi_private.profiles(id) on delete cascade,
  body text not null check (length(body) between 1 and 1000),
  created_at timestamptz not null default clock_timestamp()
);
create table if not exists sathi_private.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references sathi_private.profiles(id) on delete cascade,
  recipient_id uuid not null references sathi_private.profiles(id) on delete cascade,
  body text not null check (length(body) between 1 and 2000),
  created_at timestamptz not null default clock_timestamp(),
  check (sender_id <> recipient_id)
);
create table if not exists sathi_private.alerts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references sathi_private.profiles(id) on delete cascade,
  location_cipher bytea not null,
  message text not null check (length(message) between 1 and 500),
  created_at timestamptz not null default clock_timestamp(),
  expires_at timestamptz not null default (clock_timestamp() + interval '15 minutes'),
  resolved_at timestamptz
);
create table if not exists sathi_private.ad_plans (
  id text primary key,
  days integer not null check (days in (3,7,15,30)),
  reach text not null check (reach in ('local','state','national')),
  price integer not null check (price > 0)
);
-- Configuration, not fabricated user activity.
insert into sathi_private.ad_plans(id,days,reach,price) values
 ('3-local',3,'local',299),('3-state',3,'state',599),('3-national',3,'national',1499),
 ('7-local',7,'local',699),('7-state',7,'state',1499),('7-national',7,'national',3499),
 ('15-local',15,'local',1299),('15-state',15,'state',2799),('15-national',15,'national',6999),
 ('30-local',30,'local',2199),('30-state',30,'state',4999),('30-national',30,'national',12999)
on conflict (id) do nothing;
create table if not exists sathi_private.ads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references sathi_private.profiles(id) on delete cascade,
  plan_id text not null references sathi_private.ad_plans(id),
  price integer not null,
  title text not null check (length(title) between 1 and 120),
  description text not null check (length(description) <= 2000),
  target_url text not null check (length(target_url) <= 2048),
  media_path text,
  location_cipher bytea not null,
  city text not null,
  state text not null,
  status text not null default 'pending' check (status in ('pending','active')),
  simulated boolean not null default true check (simulated),
  views integer not null default 0 check (views >= 0),
  clicks integer not null default 0 check (clicks >= 0),
  created_at timestamptz not null default clock_timestamp(),
  activated_at timestamptz,
  expires_at timestamptz
);
create table if not exists sathi_private.payment_events (
  id uuid primary key default gen_random_uuid(),
  ad_id uuid not null unique references sathi_private.ads(id) on delete cascade,
  transaction_id text not null unique,
  mode text not null default 'simulation' check (mode = 'simulation'),
  amount integer not null,
  created_at timestamptz not null default clock_timestamp()
);
create table if not exists sathi_private.ad_events (
  ad_id uuid references sathi_private.ads(id) on delete cascade,
  viewer_id uuid references sathi_private.profiles(id) on delete cascade,
  event text check (event in ('view','click')),
  event_day date not null default ((clock_timestamp() at time zone 'UTC')::date),
  created_at timestamptz not null default clock_timestamp(),
  primary key(ad_id,viewer_id,event,event_day)
);

-- Existing baseline tables must have the columns used by the authenticated RPCs.
-- This guard prevents a partial or older table layout from being silently accepted.
do $$
declare missing text;
begin
  select string_agg(required.table_name||'.'||required.column_name, ', ' order by required.table_name,required.column_name)
    into missing
  from (values
    ('location_key','singleton'),('location_key','secret'),
    ('supported_cities','city'),('supported_cities','state'),('supported_cities','centroid_lat'),('supported_cities','centroid_lng'),
    ('profiles','id'),('profiles','name'),('profiles','avatar'),('profiles','bio'),('profiles','city'),('profiles','state'),
    ('profiles','area'),('profiles','language'),('profiles','ringtone'),('profiles','verification_status'),
    ('profiles','demo_consent_at'),('profiles','created_at'),
    ('heartbeats','user_id'),('heartbeats','location_cipher'),('heartbeats','captured_at'),('heartbeats','updated_at'),
    ('posts','id'),('posts','author_id'),('posts','caption'),('posts','category'),('posts','media_type'),('posts','media_path'),
    ('posts','location_cipher'),('posts','city'),('posts','state'),('posts','area'),('posts','created_at'),
    ('likes','post_id'),('likes','user_id'),('likes','created_at'),
    ('comments','id'),('comments','post_id'),('comments','user_id'),('comments','body'),('comments','created_at'),
    ('messages','id'),('messages','sender_id'),('messages','recipient_id'),('messages','body'),('messages','created_at'),
    ('alerts','id'),('alerts','user_id'),('alerts','location_cipher'),('alerts','message'),('alerts','created_at'),
    ('alerts','expires_at'),('alerts','resolved_at'),
    ('ad_plans','id'),('ad_plans','days'),('ad_plans','reach'),('ad_plans','price'),
    ('ads','id'),('ads','user_id'),('ads','plan_id'),('ads','price'),('ads','title'),('ads','description'),
    ('ads','target_url'),('ads','media_path'),('ads','location_cipher'),('ads','city'),('ads','state'),
    ('ads','status'),('ads','simulated'),('ads','views'),('ads','clicks'),('ads','created_at'),
    ('ads','activated_at'),('ads','expires_at'),
    ('payment_events','id'),('payment_events','ad_id'),('payment_events','transaction_id'),
    ('payment_events','mode'),('payment_events','amount'),('payment_events','created_at'),
    ('ad_events','ad_id'),('ad_events','viewer_id'),('ad_events','event'),('ad_events','event_day'),('ad_events','created_at')
  ) as required(table_name,column_name)
  where not exists (
    select 1 from information_schema.columns c
    where c.table_schema='sathi_private'
      and c.table_name=required.table_name
      and c.column_name=required.column_name
  );
  if missing is not null then
    raise exception 'Local Sathi setup stopped: required columns are missing or incompatible: %', missing;
  end if;
end $$;

-- Never create a replacement encryption key for existing posts.
do $$
begin
  if exists (select 1 from sathi_private.posts)
     and not exists (select 1 from sathi_private.location_key where singleton=true) then
    raise exception 'Local Sathi setup stopped: posts exist but the location encryption key is missing.';
  end if;
end $$;
insert into sathi_private.location_key
values (true, encode(extensions.gen_random_bytes(32), 'hex'))
on conflict (singleton) do nothing;

create index if not exists posts_author_created on sathi_private.posts(author_id, created_at desc);
create index if not exists posts_region_video on sathi_private.posts(state, city, media_type, created_at desc);
create index if not exists comments_post_created on sathi_private.comments(post_id,created_at);
create index if not exists messages_sender on sathi_private.messages(sender_id,created_at desc);
create index if not exists messages_recipient on sathi_private.messages(recipient_id,created_at desc);
create index if not exists alerts_user_created on sathi_private.alerts(user_id, created_at desc);
create index if not exists alerts_active on sathi_private.alerts(expires_at) where resolved_at is null;
create index if not exists ads_user_created on sathi_private.ads(user_id,created_at desc);
-- Every private table has RLS, no client policies and no client grants.
alter table sathi_private.location_key enable row level security;
alter table sathi_private.supported_cities enable row level security;
alter table sathi_private.profiles enable row level security;
alter table sathi_private.heartbeats enable row level security;
alter table sathi_private.posts enable row level security;
alter table sathi_private.likes enable row level security;
alter table sathi_private.comments enable row level security;
alter table sathi_private.messages enable row level security;
alter table sathi_private.alerts enable row level security;
alter table sathi_private.ad_plans enable row level security;
alter table sathi_private.ads enable row level security;
alter table sathi_private.payment_events enable row level security;
alter table sathi_private.ad_events enable row level security;

create or replace function sathi_private.actor() returns uuid
language plpgsql security definer set search_path = pg_catalog, sathi_private
as $$
declare
  u uuid := auth.uid();
  primary_provider text := coalesce(auth.jwt()->'app_metadata'->>'provider','');
  identity_provider text;
  identity_data jsonb;
  display_name text;
  avatar_url text;
begin
  if u is null or primary_provider not in ('google','email') then
    raise exception 'Use a Local Sathi email/password or Google account' using errcode = 'P0001';
  end if;
  select i.provider,i.identity_data into identity_provider,identity_data
    from auth.identities i
    where i.user_id = u and i.provider in ('google','email')
    order by case when i.provider=primary_provider then 0 else 1 end
    limit 1;
  if identity_data is null then
    raise exception 'Sign-in identity missing' using errcode = 'P0001';
  end if;
  if identity_provider='email' then
    if not exists (select 1 from auth.users where id=u and email_confirmed_at is not null) then
      raise exception 'Confirm your email address before using Local Sathi' using errcode = 'P0001';
    end if;
    display_name := left(coalesce(nullif(trim(auth.jwt()->'user_metadata'->>'full_name'),''),
      nullif(trim(split_part(identity_data->>'email','@',1)),''),'Neighbour'),120);
    avatar_url := '';
  else
    -- Google names and avatars come from provider identity data.
    display_name := left(coalesce(nullif(trim(identity_data->>'full_name'),''),
      nullif(trim(identity_data->>'name'),''),'Google user'),120);
    avatar_url := coalesce(identity_data->>'avatar_url',identity_data->>'picture','');
  end if;
  if avatar_url !~ '^https://[^[:space:]]+$' or length(avatar_url) > 2048 then avatar_url := ''; end if;
  insert into sathi_private.profiles(id,name,avatar) values (u,display_name,avatar_url)
    on conflict (id) do update set name=excluded.name, avatar=excluded.avatar
    where profiles.name is distinct from excluded.name or profiles.avatar is distinct from excluded.avatar;
  return u;
end $$;

create or replace function sathi_private.str(p jsonb, k text, lo integer, hi integer, fallback text default null)
returns text language plpgsql immutable security definer set search_path = pg_catalog
as $$
declare v text;
begin
  if p ? k and jsonb_typeof(p->k) <> 'string' then raise exception '% must be text',k; end if;
  v := trim(coalesce(p->>k,fallback));
  if v is null or length(v) < lo or length(v) > hi then raise exception 'Invalid % length (%..%)',k,lo,hi; end if;
  return v;
end $$;

create or replace function sathi_private.geo(p jsonb) returns jsonb
language plpgsql security definer set search_path = pg_catalog
as $$
declare a numeric; b numeric; c numeric; t timestamptz;
begin
  if jsonb_typeof(p->'lat') is distinct from 'number'
    or jsonb_typeof(p->'lng') is distinct from 'number'
    or jsonb_typeof(p->'accuracy') is distinct from 'number'
    or jsonb_typeof(p->'capturedAt') is distinct from 'string' then
    raise exception 'Fresh GPS latitude, longitude, accuracy and capturedAt are required';
  end if;
  a := (p->>'lat')::numeric; b := (p->>'lng')::numeric; c := (p->>'accuracy')::numeric;
  if length(p->>'capturedAt')>40 or (p->>'capturedAt') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]+)?(Z|[+-][0-9]{2}:[0-9]{2})$' then
    raise exception 'GPS capturedAt must be an ISO timestamp with timezone';
  end if;
  begin t := (p->>'capturedAt')::timestamptz;
  exception when others then raise exception 'Invalid GPS capture timestamp'; end;
  if a not between -90 and 90 or b not between -180 and 180 or c not between 0 and 1000
    or not isfinite(t) or t < clock_timestamp() - interval '5 minutes'
    or t > clock_timestamp() + interval '30 seconds' then
    raise exception 'GPS must be within range, accuracy <=1000m and captured within 5 minutes';
  end if;
  return jsonb_build_object('lat',a,'lng',b,'accuracy',c,'capturedAt',t);
end $$;

create or replace function sathi_private.seal(p jsonb) returns bytea
language sql security definer set search_path = pg_catalog
as $$ select extensions.pgp_sym_encrypt(p::text,k.secret,'cipher-algo=aes256,compress-algo=0')
      from sathi_private.location_key k where singleton $$;
create or replace function sathi_private.unseal(p bytea) returns jsonb
language sql stable security definer set search_path = pg_catalog
as $$ select extensions.pgp_sym_decrypt(p,k.secret)::jsonb from sathi_private.location_key k where singleton $$;
create or replace function sathi_private.haversine(a jsonb,b jsonb) returns double precision
language sql immutable strict security definer set search_path = pg_catalog
as $$ select 6371.0088 * 2 * asin(sqrt(least(1.0,greatest(0.0,
 power(sin(radians(((b->>'lat')::double precision-(a->>'lat')::double precision)/2)),2)
 + cos(radians((a->>'lat')::double precision))*cos(radians((b->>'lat')::double precision))
 * power(sin(radians(((b->>'lng')::double precision-(a->>'lng')::double precision)/2)),2))))) $$;

create or replace function sathi_private.region_from_geo(g jsonb) returns jsonb
language sql stable security definer set search_path = pg_catalog
as $$
  select coalesce((
    select jsonb_build_object('city',q.city,'state',q.state) from (
      select c.city,c.state,sathi_private.haversine(g,
        jsonb_build_object('lat',c.centroid_lat,'lng',c.centroid_lng)) as km
      from sathi_private.supported_cities c
    ) q where q.km<=40 order by q.km,q.state,q.city limit 1
  ),jsonb_build_object('city','','state',''))
$$;

create or replace function sathi_private.beat(u uuid,p jsonb) returns jsonb
language plpgsql security definer set search_path = pg_catalog
as $$
declare g jsonb := sathi_private.geo(p); encrypted bytea;
begin
  encrypted := sathi_private.seal(g);
  insert into sathi_private.heartbeats(user_id,location_cipher,captured_at)
    values (u,encrypted,(g->>'capturedAt')::timestamptz)
    on conflict(user_id) do update set location_cipher=excluded.location_cipher,
      captured_at=excluded.captured_at,updated_at=clock_timestamp();
  -- SOS consent is given only by createAlert; heartbeats move an existing live alert.
  update sathi_private.alerts set location_cipher=encrypted
    where user_id=u and resolved_at is null and expires_at>clock_timestamp();
  return g;
end $$;
create or replace function sathi_private.current_geo(u uuid) returns jsonb
language sql stable security definer set search_path = pg_catalog
as $$ select sathi_private.unseal(h.location_cipher) from sathi_private.heartbeats h
  where h.user_id=u and h.captured_at >= statement_timestamp()-interval '5 minutes'
  and h.updated_at >= statement_timestamp()-interval '5 minutes' $$;

create or replace function sathi_private.fallback_level(u uuid) returns text
language plpgsql stable security definer set search_path = pg_catalog
as $$
declare g jsonb := sathi_private.current_geo(u); p jsonb;
begin
  if g is null then return 'empty'; end if;
  if exists(select 1 from sathi_private.posts x where x.media_type='video'
    and sathi_private.haversine(g,sathi_private.unseal(x.location_cipher))<=5) then return 'nearby'; end if;
  p := sathi_private.region_from_geo(g);
  if p->>'city'<>'' and p->>'state'<>'' and exists(select 1 from sathi_private.posts x
    where x.media_type='video' and x.city=p->>'city' and x.state=p->>'state') then return 'city'; end if;
  if p->>'state'<>'' and exists(select 1 from sathi_private.posts x
    where x.media_type='video' and x.state=p->>'state') then return 'state'; end if;
  return 'nearby';
end $$;
create or replace function sathi_private.can_post(u uuid,pid uuid) returns boolean
language plpgsql stable security definer set search_path = pg_catalog
as $$
declare p sathi_private.posts; me jsonb; g jsonb; level text;
begin
  select * into p from sathi_private.posts where id=pid;
  if not found then return false; end if;
  if p.author_id=u then return true; end if;
  g := sathi_private.current_geo(u);
  if g is null then return false; end if;
  if sathi_private.haversine(g,sathi_private.unseal(p.location_cipher))<=5 then return true; end if;
  if p.media_type<>'video' then return false; end if;
  level := sathi_private.fallback_level(u);
  me := sathi_private.region_from_geo(g);
  return (level='city' and p.city=me->>'city' and p.state=me->>'state')
    or (level='state' and p.state=me->>'state');
end $$;
create or replace function sathi_private.can_ad(u uuid,aid uuid) returns boolean
language plpgsql stable security definer set search_path = pg_catalog
as $$
declare a sathi_private.ads; reach text; region text; g jsonb;
begin
  select * into a from sathi_private.ads where id=aid;
  if not found or a.status<>'active' or a.expires_at<=statement_timestamp() or a.expires_at is null then return false; end if;
  g := sathi_private.current_geo(u);
  if g is null then return false; end if;
  select p.reach into reach from sathi_private.ad_plans p where p.id=a.plan_id;
  region := sathi_private.region_from_geo(g)->>'state';
  return reach='national' or (reach='state' and region<>'' and lower(region)=lower(a.state))
    or (reach='local' and region<>'' and a.state<>''
      and sathi_private.haversine(g,sathi_private.unseal(a.location_cipher))<=50);
end $$;
create or replace function sathi_private.owned_object(u uuid,bucket text,path text,kind text default null) returns text
language plpgsql security definer set search_path = pg_catalog
as $$
begin
  if bucket not in ('sathi-media','sathi-identity') or path is null
    or path !~ ('^'||u::text||'/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(jpg|mp4)$')
    or (kind='video' and path !~ '\.mp4$') or (kind='image' and path !~ '\.jpg$')
    or (bucket='sathi-identity' and path !~ '\.jpg$') then
    raise exception 'Invalid owned storage object path or media type';
  end if;
  if not exists(select 1 from storage.objects o where o.bucket_id=bucket and o.name=path
    and o.owner_id=u::text) then raise exception 'Owned storage object does not exist in required bucket'; end if;
  return path;
end $$;

create or replace function sathi_private.post_json(p sathi_private.posts,u uuid) returns jsonb
language sql stable security definer set search_path = pg_catalog
as $$ select jsonb_build_object(
 'id',p.id,'authorId',p.author_id,'authorName',a.name,'avatar',a.avatar,'verified',false,
 'caption',p.caption,'category',p.category,'mediaType',p.media_type,
 'mediaUrl',coalesce(p.media_path,''),'posterUrl','','area',p.area,'city',p.city,'state',p.state,
 'distanceKm',case when sathi_private.current_geo(u) is not null then
   round(sathi_private.haversine(sathi_private.current_geo(u),sathi_private.unseal(p.location_cipher))::numeric,1) else null end,
 'likes',(select count(*) from sathi_private.likes l where l.post_id=p.id),
 'comments',(select count(*) from sathi_private.comments c where c.post_id=p.id),
 'liked',exists(select 1 from sathi_private.likes l where l.post_id=p.id and l.user_id=u),
 'createdAt',p.created_at,'isAd',false)
 from sathi_private.profiles a where a.id=p.author_id $$;
create or replace function sathi_private.ad_json(a sathi_private.ads,u uuid) returns jsonb
language sql stable security definer set search_path = pg_catalog
as $$ select jsonb_build_object(
 'id',a.id,'authorId',a.user_id,'authorName',p.name,'avatar',p.avatar,'verified',false,
 'caption',a.title||E'\n'||a.description,'category','Sponsored',
 'mediaType',case when a.media_path is null then 'text' when a.media_path like '%.mp4' then 'video' else 'image' end,
 'mediaUrl',coalesce(a.media_path,''),'posterUrl','','area','','city',a.city,'state',a.state,
 'distanceKm',null,'likes',0,'comments',0,'liked',false,'createdAt',a.created_at,
 'isAd',true,'targetUrl',a.target_url) from sathi_private.profiles p where p.id=a.user_id $$;

create or replace function public.sathi_ready() returns boolean
language sql security definer set search_path = pg_catalog
as $$
  select to_regclass('sathi_private.location_key') is not null
    and to_regclass('sathi_private.supported_cities') is not null
    and to_regclass('sathi_private.profiles') is not null
    and to_regclass('sathi_private.posts') is not null
    and to_regprocedure('public.sathi_account()') is not null
    and to_regprocedure('public.sathi_feed(jsonb)') is not null
    and to_regprocedure('public.sathi_action(text,jsonb)') is not null
    and to_regprocedure('public.sathi_delete_post(uuid)') is not null
    and exists (select 1 from storage.buckets where id='sathi-media' and public=false)
    and exists (select 1 from storage.buckets where id='sathi-identity' and public=false)
$$;

create or replace function public.sathi_email_ready() returns boolean
language sql security definer set search_path = pg_catalog
as $$ select public.sathi_ready() and to_regprocedure('sathi_private.actor()') is not null $$;

create or replace function public.sathi_account() returns jsonb
language plpgsql security definer set search_path = pg_catalog
as $$
declare u uuid := sathi_private.actor(); result jsonb;
begin
  select jsonb_build_object(
    'profile',jsonb_build_object('id',p.id,'name',p.name,'avatar',p.avatar,'bio',p.bio,
      'city',p.city,'state',p.state,'area',p.area,'language',p.language,
      'ringtone',p.ringtone,'verificationStatus',p.verification_status),
    'posts',coalesce((select jsonb_agg(sathi_private.post_json(x,u) order by x.created_at desc)
      from (select * from sathi_private.posts where author_id=u order by created_at desc limit 100) x),'[]'::jsonb),
    'ads',coalesce((select jsonb_agg(jsonb_build_object('id',a.id,'title',a.title,'description',a.description,
      'planId',a.plan_id,'price',a.price,'status',case when a.status='active' and a.expires_at<=clock_timestamp()
        then 'expired' else a.status end,'views',a.views,'clicks',a.clicks,
      'createdAt',a.created_at,'expiresAt',a.expires_at,'simulated',a.simulated) order by a.created_at desc)
      from (select * from sathi_private.ads where user_id=u order by created_at desc limit 100) a),'[]'::jsonb),
    'conversations',coalesce((select jsonb_agg(jsonb_build_object('id',q.other_id,'name',other.name,
      'avatar',other.avatar,'lastMessage',q.body,'updatedAt',q.created_at) order by q.created_at desc)
      from (select distinct on (case when m.sender_id=u then m.recipient_id else m.sender_id end)
        case when m.sender_id=u then m.recipient_id else m.sender_id end as other_id,m.body,m.created_at
        from sathi_private.messages m where m.sender_id=u or m.recipient_id=u
        order by case when m.sender_id=u then m.recipient_id else m.sender_id end,m.created_at desc,m.id desc) q
      join sathi_private.profiles other on other.id=q.other_id),'[]'::jsonb))
  into result from sathi_private.profiles p where p.id=u;
  return result;
end $$;

create or replace function public.sathi_delete_post(p_post_id uuid) returns jsonb
language plpgsql security definer set search_path = pg_catalog, sathi_private
as $$
declare
  u uuid := sathi_private.actor();
  removed_media_path text;
begin
  delete from sathi_private.posts p
    where p.id=p_post_id and p.author_id=u
    returning p.media_path into removed_media_path;
  if not found then raise exception 'Post not found or not owned' using errcode = 'P0001'; end if;
  return jsonb_build_object('deleted',true,'mediaPath',coalesce(removed_media_path,''));
end $$;

create or replace function public.sathi_feed(p_payload jsonb) returns jsonb
language plpgsql security definer set search_path = pg_catalog
as $$
declare u uuid := sathi_private.actor(); g jsonb; level text; items jsonb;
  category text; term text; kind text; me jsonb; selected_city text; selected_state text;
begin
  if jsonb_typeof(p_payload) is distinct from 'object' or octet_length(p_payload::text)>20000 then
    raise exception 'Invalid or oversized payload';
  end if;
  selected_city := sathi_private.str(p_payload,'city',0,100);
  selected_state := sathi_private.str(p_payload,'state',0,100);
  perform sathi_private.str(p_payload,'area',0,100,'');
  perform sathi_private.str(p_payload,'country',0,100,'');
  g := sathi_private.beat(u,p_payload);
  category := sathi_private.str(p_payload,'category',0,60,'');
  term := sathi_private.str(p_payload,'search',0,100,'');
  kind := sathi_private.str(p_payload,'mediaType',0,10,'');
  if kind not in ('','all','text','image','video') then raise exception 'Invalid mediaType'; end if;
  level := sathi_private.fallback_level(u);
  me := sathi_private.region_from_geo(g);
  -- The local-video test precedes ALL filters. Searching cannot unlock fallback.
  -- Own posts outside the radius remain account-only, not a feed exception.
  select coalesce(jsonb_agg(q.item order by q.sponsored,q.score desc,q.created_at desc),'[]'::jsonb) into items
  from (
    select r.* from (
      select sathi_private.post_json(p,u) as item,0 as sponsored,
        (select count(*) from sathi_private.likes l where l.post_id=p.id) as score,p.created_at
      from sathi_private.posts p
      where (sathi_private.haversine(g,sathi_private.unseal(p.location_cipher))<=5
        or (p.media_type='video' and ((level='city' and p.city=me->>'city' and p.state=me->>'state')
        or (level='state' and p.state=me->>'state'))))
      and (selected_city='' or p.city='' or lower(p.city)=lower(selected_city))
      and (selected_state='' or p.state='' or lower(p.state)=lower(selected_state))
      and (category in ('','all','All') or lower(p.category)=lower(category))
      and (kind in ('','all') or p.media_type=kind)
      and (term='' or strpos(lower(p.caption),lower(term))>0)
      order by score desc,p.created_at desc limit 35
    ) r
    union all
    select sathi_private.ad_json(a,u),1,0::bigint,a.created_at from (
      select * from sathi_private.ads a where sathi_private.can_ad(u,a.id)
      and (selected_city='' or lower(a.city)=lower(selected_city))
      and (selected_state='' or lower(a.state)=lower(selected_state))
      order by a.created_at desc limit 5
    ) a
  ) q;
  if jsonb_array_length(items)=0 then level := 'empty'; end if;
  return jsonb_build_object('posts',items,'source',level,'message',case level
    when 'city' then 'No videos within 5 km. Showing city trending videos from the nearest supported GPS centroid (approximate region). Other community posts remain within 5 km.'
    when 'state' then 'No local or GPS-city videos. Showing state trending videos from the nearest supported GPS centroid (approximate region). Other community posts remain within 5 km.'
    when 'empty' then 'No matching nearby posts yet.'
    else 'Community posts within 5 km. Sponsored campaigns are labeled and may have wider reach.' end);
end $$;

create or replace function public.sathi_action(p_operation text,p_payload jsonb) returns jsonb
language plpgsql security definer set search_path = pg_catalog
as $$
declare
  u uuid := sathi_private.actor(); pid uuid; other uuid; g jsonb; result jsonb;
  txt text; path text; kind text; region text; town text; place text;
  a sathi_private.ads; plan sathi_private.ad_plans; me sathi_private.profiles;
  changed integer; liked boolean; object_bucket text;
begin
  if jsonb_typeof(p_payload) is distinct from 'object' or octet_length(p_payload::text)>20000 then
    raise exception 'Invalid or oversized payload';
  end if;
  -- Storage RLS invokes this narrow boolean branch through the already-authorized
  -- public RPC. Internal helpers remain unexecutable by client roles.
  if p_operation='_storageRead' then
    object_bucket := sathi_private.str(p_payload,'bucket',1,40);
    path := sathi_private.str(p_payload,'path',1,200);
    if split_part(path,'/',1)=u::text then return 'true'::jsonb; end if;
    if object_bucket<>'sathi-media' then return 'false'::jsonb; end if;
    return to_jsonb(exists(select 1 from sathi_private.posts p where p.media_path=path and sathi_private.can_post(u,p.id))
      or exists(select 1 from sathi_private.ads ad where ad.media_path=path and sathi_private.can_ad(u,ad.id)));
  end if;

  -- Serialize mutations per account: race-safe quotas, toggles, SOS and ad reservations.
  -- NO KEY UPDATE still serializes this user's mutations, while allowing another
  -- participant's message FK to acquire KEY SHARE without cross-chat deadlocks.
  select * into me from sathi_private.profiles where id=u for no key update;
  case p_operation
  when 'updateProfile' then
    if p_payload ? 'name' and sathi_private.str(p_payload,'name',1,120)<>me.name then
      raise exception 'Display name comes from your Google identity and cannot be overridden';
    end if;
    if p_payload ? 'ringtone' and jsonb_typeof(p_payload->'ringtone')<>'boolean' then
      raise exception 'ringtone must be boolean';
    end if;
    if sathi_private.str(p_payload,'language',2,20,me.language) not in ('en','hi','gu','mr','ta','te','bn','kn','ml','pa') then
      raise exception 'Unsupported profile language';
    end if;
    update sathi_private.profiles set
      bio=sathi_private.str(p_payload,'bio',0,300,me.bio),
      city=sathi_private.str(p_payload,'city',0,100,me.city),
      state=sathi_private.str(p_payload,'state',0,100,me.state),
      area=sathi_private.str(p_payload,'area',0,100,me.area),
      language=sathi_private.str(p_payload,'language',2,20,me.language),
      ringtone=coalesce((p_payload->>'ringtone')::boolean,me.ringtone)
      where id=u;
    return (public.sathi_account())->'profile';
  when 'heartbeat' then
    perform sathi_private.str(p_payload,'city',1,100);
    perform sathi_private.str(p_payload,'state',1,100);
    perform sathi_private.beat(u,p_payload);
    return jsonb_build_object('active',true);
  when 'createPost' then
    perform sathi_private.str(p_payload,'city',1,100);
    perform sathi_private.str(p_payload,'state',1,100);
    perform sathi_private.str(p_payload,'area',0,100);
    g := sathi_private.beat(u,p_payload);
    result := sathi_private.region_from_geo(g);
    town := result->>'city'; region := result->>'state';
    kind := sathi_private.str(p_payload,'mediaType',1,10);
    if kind not in ('text','image','video') then raise exception 'Invalid media type'; end if;
    if (select count(*) from sathi_private.posts where author_id=u and created_at>clock_timestamp()-interval '1 hour')>=20 then
      raise exception 'Posting limit reached; try later';
    end if;
    txt := sathi_private.str(p_payload,'caption',1,2000);
    if kind<>'text' then path := sathi_private.owned_object(u,'sathi-media',p_payload->>'mediaPath',kind);
    elsif nullif(p_payload->>'mediaPath','') is not null then raise exception 'Text posts cannot attach media'; end if;
    insert into sathi_private.posts(author_id,caption,category,media_type,media_path,location_cipher,city,state,area)
      values(u,txt,sathi_private.str(p_payload,'category',1,60),kind,path,sathi_private.seal(g),town,region,me.area)
      returning id into pid;
    select sathi_private.post_json(p,u) into result from sathi_private.posts p where p.id=pid;
    return result;
  when 'deletePost' then
    pid := (p_payload->>'id')::uuid;
    delete from sathi_private.posts where id=pid and author_id=u;
    if not found then raise exception 'Post not found or not owned'; end if;
    return jsonb_build_object('deleted',true);
  when 'likePost','getComments','addComment' then
    pid := (p_payload->>'id')::uuid;
    if not sathi_private.can_post(u,pid) then raise exception 'Post unavailable; refresh your nearby location'; end if;
    if p_operation='likePost' then
      delete from sathi_private.likes where post_id=pid and user_id=u;
      liked := not found;
      if liked then insert into sathi_private.likes(post_id,user_id) values(pid,u); end if;
      return jsonb_build_object('liked',liked);
    elsif p_operation='addComment' then
      txt := sathi_private.str(p_payload,'text',1,500);
      if (select count(*) from sathi_private.comments where user_id=u and created_at>clock_timestamp()-interval '1 minute')>=10 then
        raise exception 'Comment limit reached; try later'; end if;
      insert into sathi_private.comments(post_id,user_id,body) values(pid,u,txt)
        returning jsonb_build_object('id',id,'name',me.name,'text',body,'createdAt',created_at) into result;
      return result;
    end if;
    select coalesce(jsonb_agg(jsonb_build_object('id',c.id,'name',p.name,'text',c.body,'createdAt',c.created_at)
      order by c.created_at,c.id),'[]'::jsonb) into result
      from (select * from sathi_private.comments where post_id=pid order by created_at desc,id desc limit 100) c
      join sathi_private.profiles p on p.id=c.user_id;
    return result;
  when 'getMessages','sendMessage' then
    other := (p_payload->>'userId')::uuid;
    if other is null or other=u or not exists(select 1 from sathi_private.profiles where id=other) then
      raise exception 'Invalid conversation participant';
    end if;
    if p_operation='sendMessage' then
      txt := sathi_private.str(p_payload,'text',1,2000);
      if (select count(*) from sathi_private.messages where sender_id=u and created_at>clock_timestamp()-interval '1 minute')>=20 then
        raise exception 'Message limit reached; try later'; end if;
      insert into sathi_private.messages(sender_id,recipient_id,body) values(u,other,txt)
        returning jsonb_build_object('id',id,'senderId',sender_id,'text',body,'createdAt',created_at) into result;
      return result;
    end if;
    select coalesce(jsonb_agg(jsonb_build_object('id',m.id,'senderId',m.sender_id,'text',m.body,'createdAt',m.created_at)
      order by m.created_at,m.id),'[]'::jsonb) into result from (
      select * from sathi_private.messages
      where (sender_id=u and recipient_id=other) or (sender_id=other and recipient_id=u)
      order by created_at desc,id desc limit 100) m;
    return result;
  when 'getAlerts' then
    g := sathi_private.beat(u,p_payload);
    select coalesce(jsonb_agg(jsonb_build_object('id',x.id,'name',p.name,'verified',false,
      'lat',(sathi_private.unseal(x.location_cipher)->>'lat')::numeric,
      'lng',(sathi_private.unseal(x.location_cipher)->>'lng')::numeric,
      'message',x.message,'createdAt',x.created_at,'expiresAt',x.expires_at,'isOwn',x.user_id=u)
      order by x.created_at desc),'[]'::jsonb) into result
      from (select * from sathi_private.alerts al where al.resolved_at is null and al.expires_at>clock_timestamp()
        and sathi_private.haversine(g,sathi_private.unseal(al.location_cipher))<=5
        order by al.created_at desc limit 100) x
      join sathi_private.profiles p on p.id=x.user_id;
    return result;
  when 'createAlert' then
    g := sathi_private.beat(u,p_payload);
    txt := sathi_private.str(p_payload,'message',1,300,'I need help nearby.');
    if exists(select 1 from sathi_private.alerts where user_id=u and created_at>clock_timestamp()-interval '5 minutes') then
      raise exception 'One SOS per five minutes, including resolved alerts';
    end if;
    if exists(select 1 from sathi_private.alerts where user_id=u and resolved_at is null and expires_at>clock_timestamp()) then
      raise exception 'An SOS is already active; resolve it first';
    end if;
    insert into sathi_private.alerts(user_id,location_cipher,message) values(u,sathi_private.seal(g),txt)
      returning jsonb_build_object('id',id,'expiresAt',expires_at,'createdAt',created_at) into result;
    return result;
  when 'resolveAlert' then
    pid := (p_payload->>'id')::uuid;
    update sathi_private.alerts set resolved_at=coalesce(resolved_at,clock_timestamp()) where id=pid and user_id=u;
    if not found then raise exception 'Alert not found or not owned'; end if;
    return jsonb_build_object('resolved',true);
  when 'mockVerify' then
    if p_payload->'consent' is distinct from 'true'::jsonb then raise exception 'Explicit demo consent required'; end if;
    perform sathi_private.owned_object(u,'sathi-identity',p_payload->>'aadhaarPath','image');
    perform sathi_private.owned_object(u,'sathi-identity',p_payload->>'selfiePath','image');
    if p_payload->>'aadhaarPath'=p_payload->>'selfiePath' then raise exception 'Two separate images required'; end if;
    update sathi_private.profiles set verification_status='demo_verified',demo_consent_at=clock_timestamp() where id=u;
    -- Never save identity paths or extracted identifiers; Storage API must remove bytes.
    return jsonb_build_object('status','demo_verified',
      'message','Demo only: no Aadhaar validation, face comparison or real identity verification was performed. Delete both uploaded images.');
  when 'createAd' then
    perform 1 from sathi_private.profiles where id=u for update;
    perform sathi_private.str(p_payload,'city',1,100);
    perform sathi_private.str(p_payload,'state',1,100);
    g := sathi_private.beat(u,p_payload);
    result := sathi_private.region_from_geo(g);
    town := result->>'city'; region := result->>'state';
    if exists(select 1 from sathi_private.ads where user_id=u and created_at>clock_timestamp()-interval '24 hours') then
      raise exception 'One campaign per rolling 24 hours; pending campaigns also count';
    end if;
    select * into plan from sathi_private.ad_plans where id=p_payload->>'planId';
    if not found then raise exception 'Unknown ad plan'; end if;
    txt := sathi_private.str(p_payload,'targetUrl',1,1000);
    if txt !~* '^https?://[a-z0-9]([a-z0-9.-]*[a-z0-9])?(:[0-9]{1,5})?([/?#][^[:space:]<>]*)?$'
      or txt ~ '[\\]' then raise exception 'Use a valid http(s) destination URL without credentials'; end if;
    if nullif(p_payload->>'mediaPath','') is not null then path := sathi_private.owned_object(u,'sathi-media',p_payload->>'mediaPath'); end if;
    if plan.reach in ('local','state') and region='' then
      raise exception 'Regional campaigns require GPS within 40 km of a supported city';
    end if;
    insert into sathi_private.ads(user_id,plan_id,price,title,description,target_url,media_path,location_cipher,city,state)
      values(u,plan.id,plan.price,sathi_private.str(p_payload,'title',3,100),
        sathi_private.str(p_payload,'description',5,1000),txt,path,sathi_private.seal(g),town,region)
      returning id into pid;
    return jsonb_build_object('adId',pid,'price',plan.price,
      'qrData','LOCAL-SATHI-TEST|ref='||pid::text||'|INR='||plan.price::text,'upiIntent',null,'simulated',true);
  when 'simulatePayment' then
    pid := (p_payload->>'adId')::uuid;
    select * into a from sathi_private.ads where id=pid and user_id=u for update;
    if not found then raise exception 'Campaign not found or not owned'; end if;
    if not a.simulated then raise exception 'Real payments cannot be activated by simulation'; end if;
    if a.status='pending' then
      select * into plan from sathi_private.ad_plans where id=a.plan_id;
      update sathi_private.ads set status='active',activated_at=clock_timestamp(),
        expires_at=clock_timestamp()+make_interval(days=>plan.days) where id=a.id;
      insert into sathi_private.payment_events(ad_id,transaction_id,amount)
        values(a.id,'SIM-'||gen_random_uuid()::text,a.price);
    end if;
    return jsonb_build_object('adId',a.id,'status','active','simulated',true);
  when 'adEvent' then
    pid := (p_payload->>'id')::uuid;
    txt := sathi_private.str(p_payload,'event',1,5);
    if txt not in ('view','click') then raise exception 'Invalid campaign event'; end if;
    if not sathi_private.can_ad(u,pid) then raise exception 'Campaign is not currently visible'; end if;
    if exists(select 1 from sathi_private.ads where id=pid and user_id=u) then return jsonb_build_object('counted',false); end if;
    insert into sathi_private.ad_events(ad_id,viewer_id,event) values(pid,u,txt) on conflict do nothing;
    get diagnostics changed = row_count;
    if changed=1 then
      update sathi_private.ads set views=views+case when txt='view' then 1 else 0 end,
        clicks=clicks+case when txt='click' then 1 else 0 end where id=pid;
    end if;
    return jsonb_build_object('counted',changed=1);
  else raise exception 'Unsupported operation';
  end case;
exception
  when invalid_text_representation or numeric_value_out_of_range
    or invalid_datetime_format or datetime_field_overflow then
    raise exception 'Invalid identifier, number or timestamp' using errcode = 'P0001';
end $$;

-- Only the public health, account, feed, and action RPCs are callable.
revoke all on all tables in schema sathi_private from public,anon,authenticated,service_role;
revoke all on all sequences in schema sathi_private from public,anon,authenticated,service_role;
revoke all on all functions in schema sathi_private from public,anon,authenticated,service_role;
revoke all on function public.sathi_ready() from public,anon,authenticated,service_role;
revoke all on function public.sathi_email_ready() from public,anon,authenticated,service_role;
revoke all on function public.sathi_account() from public,anon,authenticated,service_role;
revoke all on function public.sathi_delete_post(uuid) from public,anon,authenticated,service_role;
revoke all on function public.sathi_feed(jsonb) from public,anon,authenticated,service_role;
revoke all on function public.sathi_action(text,jsonb) from public,anon,authenticated,service_role;
grant execute on function public.sathi_ready() to anon,authenticated;
grant execute on function public.sathi_email_ready() to anon,authenticated;
grant execute on function public.sathi_account(),public.sathi_delete_post(uuid),public.sathi_feed(jsonb),public.sathi_action(text,jsonb) to authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('sathi-media','sathi-media',false,52428800,array['image/jpeg','video/mp4']),
       ('sathi-identity','sathi-identity',false,10485760,array['image/jpeg'])
on conflict (id) do update set
  name=excluded.name,
  public=false,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

-- Recreate the Sathi Storage policies only after their RPC dependency exists.
-- Restrictive policies also guard against broad permissive policies previously
-- installed for other buckets; these restrictions do not affect other buckets.
create policy sathi_storage_guard on storage.objects as restrictive for all to anon,authenticated
using (bucket_id not in ('sathi-media','sathi-identity') or (
  auth.uid() is not null and coalesce(auth.jwt()->'app_metadata'->>'provider','') in ('google','email')
  and public.sathi_action('_storageRead',jsonb_build_object('bucket',bucket_id,'path',name))='true'::jsonb))
with check (bucket_id not in ('sathi-media','sathi-identity') or (
  auth.uid() is not null and coalesce(auth.jwt()->'app_metadata'->>'provider','') in ('google','email')
  and owner_id=auth.uid()::text
  and name ~ ('^'||auth.uid()::text||'/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.'
    ||case when bucket_id='sathi-identity' then '(jpg)$' else '(jpg|mp4)$' end)));
create policy sathi_storage_insert on storage.objects for insert to authenticated
with check (bucket_id in ('sathi-media','sathi-identity') and owner_id=auth.uid()::text
  and split_part(name,'/',1)=auth.uid()::text
  and coalesce(auth.jwt()->'app_metadata'->>'provider','') in ('google','email'));
create policy sathi_storage_select on storage.objects for select to authenticated
using (bucket_id in ('sathi-media','sathi-identity')
  and public.sathi_action('_storageRead',jsonb_build_object('bucket',bucket_id,'path',name))='true'::jsonb);
create policy sathi_storage_delete on storage.objects for delete to authenticated
using (bucket_id in ('sathi-media','sathi-identity') and owner_id=auth.uid()::text and split_part(name,'/',1)=auth.uid()::text);
-- No overwrites: a signed/referenced object cannot be swapped after attaching.
create policy sathi_storage_no_update on storage.objects as restrictive for update to anon,authenticated
using (bucket_id not in ('sathi-media','sathi-identity'))
with check (bucket_id not in ('sathi-media','sathi-identity'));
create policy sathi_storage_delete_guard on storage.objects as restrictive for delete to anon,authenticated
using (bucket_id not in ('sathi-media','sathi-identity')
  or (owner_id=auth.uid()::text and split_part(name,'/',1)=auth.uid()::text));

notify pgrst,'reload schema';
commit;