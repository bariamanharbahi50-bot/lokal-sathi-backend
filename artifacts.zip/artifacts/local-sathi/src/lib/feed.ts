import { useCallback, useEffect, useRef, useState } from 'react';
import { useGetExploreFeed, getGetExploreFeedQueryKey, useLoadNearbyFeed, type FeedResult } from '@workspace/api-client-react';
import { useAuth } from './auth';
import { useGeo } from './geo';
import { errMsg } from './action';

export function useFeed(opts: { category?: string; search?: string; mediaType?: string }) {
  const { authed } = useAuth();
  const geo = useGeo();
  const hasFix = !!geo.fix;
  const live = authed && hasFix;
  const explore = useGetExploreFeed({ query: { queryKey: getGetExploreFeedQueryKey(), enabled: !live } });
  const nearby = useLoadNearbyFeed();
  const mutRef = useRef(nearby.mutateAsync);
  mutRef.current = nearby.mutateAsync;
  const [result, setResult] = useState<FeedResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { getFresh, placeIsDemo } = geo;
  const place = placeIsDemo ? { country: '', state: '', city: '', area: '' } : geo.place;

  const reload = useCallback(async () => {
    if (!live) return;
    setLoading(true);
    setError(null);
    try {
      const f = await getFresh();
      const r = await mutRef.current({
        data: {
          ...f,
          city: place.city,
          state: place.state,
          area: place.area || undefined,
          country: place.country || undefined,
          category: opts.category && opts.category !== 'all' ? opts.category : undefined,
          search: opts.search || undefined,
          mediaType: opts.mediaType,
        },
      });
      setResult(r);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [live, getFresh, place.city, place.state, place.area, place.country, opts.category, opts.search, opts.mediaType]);

  useEffect(() => {
    void reload();
  }, [reload]);

  if (!live) {
    const all = explore.data?.posts ?? [];
    const q = (opts.search || '').toLowerCase();
    const posts = all.filter(
      (p) =>
        (!opts.category || opts.category === 'all' || p.category === opts.category) &&
        (!q || `${p.caption} ${p.area} ${p.city} ${p.authorName}`.toLowerCase().includes(q)) &&
        (!opts.mediaType || p.mediaType === opts.mediaType || (opts.mediaType === 'video' && p.mediaType !== 'text')),
    );
    return {
      live,
      posts,
      source: explore.data?.source ?? 'demo',
      message: explore.data?.message ?? '',
      sample: true,
      loading: explore.isLoading,
      error: explore.isError ? errMsg(explore.error) : null,
      reload: () => void explore.refetch(),
    };
  }
  return {
    live,
    posts: result?.posts ?? [],
    source: result?.source ?? 'nearby',
    message: result?.message ?? '',
    sample: result?.source === 'demo',
    loading: loading && !result,
    error,
    reload: () => void reload(),
  };
}

export const SOURCE_LABEL: Record<string, string> = {
  nearby: 'Live · within 5 km of you',
  city: 'Fallback · your city',
  state: 'Fallback · your state',
  demo: 'Sample content · not real neighbours',
  empty: 'Nothing nearby yet',
};
