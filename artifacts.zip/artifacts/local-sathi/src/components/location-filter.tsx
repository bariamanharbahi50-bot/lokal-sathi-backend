import { useState } from 'react';
import { MapPinned } from 'lucide-react';
import { useGetPlaces, getGetPlacesQueryKey } from '@workspace/api-client-react';
import { useGeo, type Place } from '@/lib/geo';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

function Pick({ label, value, options, onChange, testid }: { label: string; value: string; options: string[]; onChange: (v: string) => void; testid: string }) {
  return (
    <label className="block">
      <span className="mb-1 block font-data text-[10px] uppercase tracking-widest text-muted-foreground">{label}</span>
      <Select value={value || '__any'} onValueChange={(v) => onChange(v === '__any' ? '' : v)}>
        <SelectTrigger data-testid={testid} className="rounded-xl bg-card">
          <SelectValue placeholder={`कोई भी ${label}`} />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="__any">Any {label.toLowerCase()}</SelectItem>
          {options.map((o) => (
            <SelectItem key={o} value={o}>
              {o}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </label>
  );
}

export function LocationFilter() {
  const { place, setPlace, placeIsDemo } = useGeo();
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Place>(place);
  const params = { country: draft.country || undefined, state: draft.state || undefined, city: draft.city || undefined };
  const places = useGetPlaces(params, { query: { queryKey: getGetPlacesQueryKey(params), enabled: open } });
  const d = places.data;

  return (
    <>
      <button
        onClick={() => {
          setDraft(place);
          setOpen(true);
        }}
        data-testid="button-location-filter"
        className="group flex items-center gap-2 rounded-full border bg-card py-1.5 pl-2 pr-4 text-left transition hover:border-primary/40"
      >
        <span className="grid h-8 w-8 place-items-center rounded-full bg-primary text-primary-foreground transition group-hover:rotate-12">
          <MapPinned className="h-4 w-4" />
        </span>
        <span className="leading-tight">
          <span className="block text-sm font-semibold">{place.area || place.city || place.state || 'India'}</span>
          <span className="block text-[11px] text-muted-foreground">
            {placeIsDemo ? "Demo label · live feed uses your GPS region" : [place.city, place.state].filter(Boolean).join(", ")}
          </span>
        </span>
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="rounded-3xl">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Choose your mohalla</DialogTitle>
            <DialogDescription>
              Labels your posts and the city/state fallback. Your 5 km nearby radius always comes from your live GPS — filters never widen it.
            </DialogDescription>
          </DialogHeader>
          {places.isLoading ? (
            <div className="grid gap-3">
              {[0, 1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-10 rounded-xl" />
              ))}
            </div>
          ) : places.isError ? (
            <p className="text-sm text-destructive">Could not load sample places. Try reopening.</p>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              <Pick label="Country" testid="select-country" value={draft.country} options={d?.countries ?? []} onChange={(v) => setDraft({ country: v, state: '', city: '', area: '' })} />
              <Pick label="State" testid="select-state" value={draft.state} options={d?.states ?? []} onChange={(v) => setDraft({ ...draft, state: v, city: '', area: '' })} />
              <Pick label="City" testid="select-city" value={draft.city} options={d?.cities ?? []} onChange={(v) => setDraft({ ...draft, city: v, area: '' })} />
              <Pick label="Area" testid="select-area" value={draft.area} options={d?.areas ?? []} onChange={(v) => setDraft({ ...draft, area: v })} />
            </div>
          )}
          <Button
            className="mt-2 rounded-full"
            data-testid="button-apply-location"
            onClick={() => {
              setPlace(draft);
              setOpen(false);
            }}
          >
            Apply
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}
