import { useEffect, useRef, useState } from 'react';
import { Link } from 'wouter';
import { Heart, MessageSquareText, Volume2, VolumeX, ArrowLeft, MapPin } from 'lucide-react';
import type { Post } from '@workspace/api-client-react';
import { useFeed } from '@/lib/feed';
import { categoryImage, initials } from '@/lib/action';
import { SampleTag, ErrorBox } from '@/components/notices';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

function Reel({ post, muted, sample, onToggleMute }: { post: Post; muted: boolean; sample: boolean; onToggleMute: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const vid = useRef<HTMLVideoElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting && e.intersectionRatio > 0.6), { threshold: [0, 0.6, 1] });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  useEffect(() => {
    const v = vid.current;
    if (!v) return;
    if (visible) v.play().catch(() => undefined);
    else v.pause();
  }, [visible]);
  const isVideo = post.mediaType === 'video' && !!post.mediaUrl;
  return (
    <div ref={ref} className="relative h-[100dvh] w-full snap-start snap-always overflow-hidden bg-sidebar" data-testid={`reel-${post.id}`}>
      {isVideo ? (
        <video ref={vid} src={post.mediaUrl} poster={post.posterUrl || categoryImage(post.category)} muted={muted} loop playsInline className="h-full w-full object-cover" />
      ) : (
        <img src={post.mediaUrl || categoryImage(post.category)} onError={(e) => ((e.target as HTMLImageElement).src = categoryImage(post.category))} alt="" className={cn('h-full w-full object-cover', visible && 'kenburns')} />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-[hsl(232_50%_8%/.9)] via-transparent to-[hsl(232_50%_8%/.4)]" />
      <div className={cn('absolute inset-x-0 bottom-0 p-5 pb-28 text-[hsl(40_48%_95%)] transition-all duration-700 md:pb-10', visible ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0')}>
        <div className="flex items-center gap-2">
          <span className="grid h-10 w-10 place-items-center rounded-full bg-accent font-semibold text-accent-foreground">{initials(post.authorName)}</span>
          <div>
            <p className="font-semibold">{post.authorName}</p>
            <p className="flex items-center gap-1 text-xs opacity-80">
              <MapPin className="h-3 w-3" /> {[post.area, post.city].filter(Boolean).join(', ')}
            </p>
          </div>
          {sample && <SampleTag className="ml-2 bg-card/90" />}
          {post.isAd && <span className="ml-2 rounded-full bg-accent px-2 py-0.5 font-data text-[10px] uppercase text-accent-foreground">Sponsored</span>}
        </div>
        <p className="mt-3 max-w-md font-display text-xl font-semibold leading-snug">{post.caption}</p>
        {!isVideo && <p className="mt-1 font-data text-[10px] uppercase tracking-widest opacity-60">Photo moment</p>}
      </div>
      <div className="absolute bottom-32 right-4 flex flex-col items-center gap-5 text-[hsl(40_48%_95%)] md:bottom-14">
        <div className="flex flex-col items-center gap-1">
          <Heart className={cn('h-7 w-7', post.liked && 'fill-destructive text-destructive')} />
          <span className="font-data text-xs">{post.likes}</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <MessageSquareText className="h-7 w-7" />
          <span className="font-data text-xs">{post.comments}</span>
        </div>
        {isVideo && (
          <button onClick={onToggleMute} className="grid h-11 w-11 place-items-center rounded-full bg-[hsl(40_48%_95%/.15)] backdrop-blur" data-testid={`button-mute-${post.id}`}>
            {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          </button>
        )}
      </div>
    </div>
  );
}

export default function ReelsPage() {
  const feed = useFeed({ mediaType: 'video' });
  const [muted, setMuted] = useState(true);
  const sampleReel: Post | null = feed.sample
    ? { id: 'sample-reel', authorId: 'sample', authorName: 'Sample showcase', avatar: '', verified: false, caption: 'Evening dabeli rush at the corner stall — a sample clip showing how reels look.', category: 'food', mediaType: 'video', mediaUrl: `${import.meta.env.BASE_URL}images/neighborhood-food.mp4`, posterUrl: `${import.meta.env.BASE_URL}images/neighborhood-food.png`, area: 'Navrangpura', city: 'Ahmedabad', state: 'Gujarat', distanceKm: null, likes: 0, comments: 0, liked: false, createdAt: new Date().toISOString(), isAd: false }
    : null;
  const base = feed.posts.some((p) => p.mediaUrl.endsWith('neighborhood-food.mp4')) || !sampleReel ? feed.posts : [sampleReel, ...feed.posts];
  const reels = [...base].filter((p) => p.mediaType !== 'text').sort((a, b) => Number(b.mediaType === 'video') - Number(a.mediaType === 'video'));
  return (
    <div className="relative bg-sidebar">
      <div className="absolute left-0 right-0 top-0 z-20 flex items-center justify-between p-4 text-[hsl(40_48%_95%)]">
        <Link href="/" className="grid h-10 w-10 place-items-center rounded-full bg-[hsl(40_48%_95%/.15)] backdrop-blur md:hidden" data-testid="link-reels-back">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <p className="font-display text-xl font-extrabold">
          Mohalla <span className="text-accent">Reels</span>
        </p>
        <span className="font-data text-[10px] uppercase tracking-widest opacity-75">{feed.live ? 'Nearby' : 'Sample'}</span>
      </div>
      {feed.loading ? (
        <div className="grid h-[100dvh] place-items-center p-8">
          <Skeleton className="h-[70dvh] w-full max-w-sm rounded-3xl bg-sidebar-accent" />
        </div>
      ) : feed.error ? (
        <div className="grid h-[100dvh] place-items-center p-6">
          <ErrorBox message={feed.error} onRetry={feed.reload} />
        </div>
      ) : reels.length === 0 ? (
        <div className="grid h-[100dvh] place-items-center p-8 text-center text-sidebar-foreground">
          <div>
            <p className="font-display text-3xl font-bold">No reels nearby yet</p>
            <p className="mt-2 opacity-75">Shoot a 15-second clip of your gali and post it from the Mohalla feed.</p>
            <Link href="/" className="mt-5 inline-block rounded-full bg-accent px-5 py-2.5 font-semibold text-accent-foreground" data-testid="link-reels-create">
              Go to feed
            </Link>
          </div>
        </div>
      ) : (
        <div className="no-scrollbar h-[100dvh] snap-y snap-mandatory overflow-y-scroll" data-testid="container-reels">
          {reels.map((p) => (
            <Reel key={p.id} post={p} muted={muted} sample={feed.sample} onToggleMute={() => setMuted((m) => !m)} />
          ))}
        </div>
      )}
    </div>
  );
}
