import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { useAuth } from './auth';
import { useAct, prefs } from './action';

export type Fix = { lat: number; lng: number; accuracy: number; capturedAt: string };
export type Place = { country: string; state: string; city: string; area: string };
type Status = 'idle' | 'asking' | 'ok' | 'denied' | 'inaccurate' | 'unsupported' | 'error';

export type Alert = {
  id: string;
  name: string;
  verified: boolean;
  lat: number;
  lng: number;
  message: string;
  createdAt: string;
  expiresAt: string;
  isOwn: boolean;
};

type GeoCtx = {
  fix: Fix | null;
  status: Status;
  statusText: string;
  request: () => Promise<Fix | null>;
  getFresh: () => Promise<Fix>;
  place: Place;
  placeIsDemo: boolean;
  setPlace: (p: Place) => void;
  alerts: Alert[];
  alertsError: string | null;
  refreshAlerts: () => Promise<void>;
  ringtone: boolean;
  setRingtone: (on: boolean) => void;
  testTone: () => void;
};

const FIVE_MIN = 5 * 60 * 1000;
export const DEMO_PLACE: Place = { country: 'India', state: 'Gujarat', city: 'Ahmedabad', area: 'Navrangpura' };
const Ctx = createContext<GeoCtx | null>(null);

function readPosition(): Promise<Fix> {
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) return reject(Object.assign(new Error('unsupported'), { code: 'unsupported' }));
    navigator.geolocation.getCurrentPosition(
      (p) =>
        resolve({
          lat: p.coords.latitude,
          lng: p.coords.longitude,
          accuracy: Math.round(p.coords.accuracy),
          capturedAt: new Date(p.timestamp || Date.now()).toISOString(),
        }),
      (e) => reject(Object.assign(new Error(e.message), { code: e.code === 1 ? 'denied' : 'error' })),
      { enableHighAccuracy: true, maximumAge: 0, timeout: 20000 },
    );
  });
}

export function GeoProvider({ children }: { children: ReactNode }) {
  const { authed } = useAuth();
  const { act } = useAct();
  const [fix, setFix] = useState<Fix | null>(null);
  const [status, setStatus] = useState<Status>('idle');
  const [statusText, setStatusText] = useState('Location not shared yet.');
  const [place, setPlaceState] = useState<Place>(DEMO_PLACE);
  const [placeIsDemo, setPlaceIsDemo] = useState(true);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [alertsError, setAlertsError] = useState<string | null>(null);
  const [ringtone, setRingtoneState] = useState(prefs.getRingtone());
  const fixRef = useRef<Fix | null>(null);
  fixRef.current = fix;
  const audioRef = useRef<AudioContext | null>(null);
  const watchId = useRef<number | null>(null);
  const stopWatch = useCallback(() => {
    if (watchId.current != null) navigator.geolocation.clearWatch(watchId.current);
    watchId.current = null;
  }, []);
  useEffect(() => stopWatch, [stopWatch]);
  const seen = useRef<Set<string> | null>(null);
  const ringRef = useRef(ringtone);
  ringRef.current = ringtone;

  useEffect(() => {
    const unlock = () => {
      if (!audioRef.current) {
        try {
          audioRef.current = new AudioContext();
        } catch {
          /* no audio */
        }
      }
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, []);

  const playTone = useCallback(() => {
    const ctx = audioRef.current;
    if (!ctx) return;
    void ctx.resume();
    const t = ctx.currentTime;
    [0, 0.35, 0.7, 1.05].forEach((off, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'triangle';
      o.frequency.value = i % 2 ? 660 : 880;
      g.gain.setValueAtTime(0.0001, t + off);
      g.gain.exponentialRampToValueAtTime(0.25, t + off + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, t + off + 0.3);
      o.connect(g).connect(ctx.destination);
      o.start(t + off);
      o.stop(t + off + 0.32);
    });
  }, []);

  const request = useCallback(async () => {
    setStatus('asking');
    setStatusText('Asking your browser for a fresh location…');
    try {
      const f = await readPosition();
      if (f.accuracy > 1000) {
        setFix(null);
        setStatus('inaccurate');
        setStatusText(`Location too imprecise (±${f.accuracy} m). Move near a window or enable precise location.`);
        return null;
      }
      setFix(f);
      setStatus('ok');
      setStatusText(`Location enabled (±${f.accuracy} m). Memory-only on this device; encrypted when saved to Supabase.`);
      if (watchId.current == null && 'geolocation' in navigator) {
        watchId.current = navigator.geolocation.watchPosition(
          (p) => {
            const acc = Math.round(p.coords.accuracy);
            if (acc > 1000) return;
            setFix({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: acc, capturedAt: new Date(p.timestamp || Date.now()).toISOString() });
            setStatusText(`Live location on (±${acc} m). Memory-only on this device; encrypted when saved to Supabase.`);
          },
          () => undefined,
          { enableHighAccuracy: true, maximumAge: 15000, timeout: 30000 },
        );
      }
      return f;
    } catch (e) {
      const code = (e as { code?: string }).code;
      setFix(null);
      if (code === 'unsupported') {
        setStatus('unsupported');
        setStatusText('This browser does not support location.');
      } else if (code === 'denied') {
        setStatus('denied');
        setStatusText('Location permission denied. Allow it in browser settings to see your 5 km neighbourhood.');
      } else {
        setStatus('error');
        setStatusText('Could not read location. Try again.');
      }
      return null;
    }
  }, []);

  const getFresh = useCallback(async () => {
    const f = fixRef.current;
    if (f && Date.now() - new Date(f.capturedAt).getTime() < FIVE_MIN) return f;
    const n = await request();
    if (!n) throw new Error('A fresh, precise location (within 1 km accuracy) is needed for this.');
    return n;
  }, [request]);

  const setPlace = useCallback((p: Place) => {
    setPlaceState(p);
    setPlaceIsDemo(false);
  }, []);

  const refreshAlerts = useCallback(async () => {
    if (!authed || !fixRef.current) return;
    try {
      const f = await getFresh();
      const list = await act<Alert[]>('getAlerts', { lat: f.lat, lng: f.lng, accuracy: f.accuracy, capturedAt: f.capturedAt });
      const arr = Array.isArray(list) ? list : [];
      if (seen.current) {
        const fresh = arr.filter((a) => !a.isOwn && !seen.current!.has(a.id));
        if (fresh.length && ringRef.current) playTone();
      }
      seen.current = new Set(arr.map((a) => a.id));
      setAlerts(arr);
      setAlertsError(null);
    } catch (e) {
      setAlertsError((e as Error).message || 'Could not load alerts.');
    }
  }, [authed, act, getFresh, playTone]);

  const hasFix = !!fix;
  useEffect(() => {
    if (!authed || !hasFix) return;
    void refreshAlerts();
    const id = setInterval(() => void refreshAlerts(), 5000);
    return () => clearInterval(id);
  }, [authed, hasFix, refreshAlerts]);

  const placeRef = useRef(place);
  placeRef.current = place;
  const placeDemoRef = useRef(placeIsDemo);
  placeDemoRef.current = placeIsDemo;
  useEffect(() => {
    if (!authed || !hasFix) return;
    const beat = async () => {
      try {
        const f = await getFresh();
        const pd = placeDemoRef.current;
        await act('heartbeat', { ...f, city: pd ? '' : placeRef.current.city, state: pd ? '' : placeRef.current.state });
      } catch {
        /* heartbeat best-effort; status surfaces elsewhere */
      }
    };
    void beat();
    const id = setInterval(beat, 60_000);
    return () => clearInterval(id);
  }, [authed, hasFix, act, getFresh]);

  useEffect(() => {
    if (!authed) {
      setAlerts([]);
      seen.current = null;
      stopWatch();
      setFix(null);
      setStatus('idle');
      setStatusText('Location not shared yet.');
    }
  }, [authed, stopWatch]);

  const setRingtone = useCallback((on: boolean) => {
    prefs.setRingtone(on);
    setRingtoneState(on);
  }, []);

  return (
    <Ctx.Provider
      value={{ fix, status, statusText, request, getFresh, place, placeIsDemo, setPlace, alerts, alertsError, refreshAlerts, ringtone, setRingtone, testTone: playTone }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useGeo() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useGeo outside provider');
  return c;
}
