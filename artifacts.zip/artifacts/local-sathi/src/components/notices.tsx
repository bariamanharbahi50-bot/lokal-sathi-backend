import { Link } from 'wouter';
import { MapPin, LogIn, Wrench, LocateFixed, Loader2 } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useGeo } from '@/lib/geo';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export function SampleTag({ className }: { className?: string }) {
  return (
    <span
      data-testid="tag-sample"
      className={cn(
        'inline-flex items-center gap-1 rounded-full border border-dashed border-primary/40 bg-accent/25 px-2.5 py-0.5 font-data text-[10px] uppercase tracking-widest text-primary',
        className,
      )}
    >
      Sample content
    </span>
  );
}

export function AuthNotice({ what }: { what: string }) {
  const { setupNeeded, authed, config } = useAuth();
  if (authed) return null;
  if (setupNeeded)
    return (
      <div data-testid="notice-setup" className="rise rounded-2xl border border-dashed border-primary/30 bg-card p-4 jaali">
        <div className="flex items-start gap-3">
          <Wrench className="mt-0.5 h-5 w-5 shrink-0 text-secondary" />
          <div className="flex-1 text-sm">
            <p className="font-display text-base font-semibold">Setup needed to {what}</p>
            <p className="mt-1 text-muted-foreground">
              {config?.setupMessage || 'Sign-in or the database is not configured yet.'} You can keep exploring sample content.
            </p>
            <Link href="/setup" data-testid="link-setup" className="mt-2 inline-block font-semibold text-primary underline underline-offset-4">
              See setup steps
            </Link>
          </div>
        </div>
      </div>
    );
  return (
    <div data-testid="notice-auth" className="rise flex items-center gap-3 rounded-2xl border bg-card p-4">
      <LogIn className="h-5 w-5 shrink-0 text-primary" />
      <p className="flex-1 text-sm">
        <span className="font-semibold">Sign in to {what}.</span> <span className="text-muted-foreground">Real neighbours only — no fake profiles.</span>
      </p>
      <Link href="/login" data-testid="link-login" className="rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
        Sign in
      </Link>
    </div>
  );
}

export function LocationNotice({ compact }: { compact?: boolean }) {
  const { fix, status, statusText, request } = useGeo();
  if (fix && compact) return null;
  return (
    <div data-testid="notice-location" className={cn('rise flex items-center gap-3 rounded-2xl border p-4', fix ? 'bg-secondary/10 border-secondary/30' : 'bg-card')}>
      <div className="relative grid h-10 w-10 shrink-0 place-items-center rounded-full bg-secondary text-secondary-foreground">
        {!fix && <span className="pulse-ring absolute inset-0 rounded-full bg-secondary/40" />}
        <MapPin className="relative h-5 w-5" />
      </div>
      <p className="flex-1 text-sm text-muted-foreground" data-testid="text-location-status">
        {fix ? statusText : status === 'idle' ? 'Share a fresh location to see neighbours within 5 km. Never stored on this device.' : statusText}
      </p>
      <Button size="sm" variant={fix ? 'outline' : 'default'} onClick={() => void request()} disabled={status === 'asking'} data-testid="button-share-location" className="rounded-full">
        {status === 'asking' ? <Loader2 className="h-4 w-4 animate-spin" /> : <LocateFixed className="h-4 w-4" />}
        {fix ? 'Refresh' : 'Share'}
      </Button>
    </div>
  );
}

export function EmptyArt({ title, body, children }: { title: string; body: string; children?: React.ReactNode }) {
  return (
    <div className="rise flex flex-col items-center rounded-3xl border border-dashed bg-card/60 px-6 py-12 text-center jaali" data-testid="state-empty">
      <div className="mb-4 grid h-16 w-16 rotate-45 place-items-center rounded-xl border-2 border-accent">
        <div className="h-6 w-6 rounded-full bg-destructive/80" />
      </div>
      <p className="font-display text-xl font-semibold">{title}</p>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">{body}</p>
      {children && <div className="mt-4">{children}</div>}
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div data-testid="state-error" className="rounded-2xl border border-destructive/30 bg-destructive/5 p-4 text-sm">
      <p className="font-semibold text-destructive">Kuch gadbad hui</p>
      <p className="mt-1 text-foreground/80">{message}</p>
      {onRetry && (
        <Button size="sm" variant="outline" className="mt-3 rounded-full" onClick={onRetry} data-testid="button-retry">
          Try again
        </Button>
      )}
    </div>
  );
}
