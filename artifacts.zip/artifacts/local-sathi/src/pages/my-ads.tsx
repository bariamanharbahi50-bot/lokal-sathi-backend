import { Link } from 'wouter';
import { Eye, MousePointerClick, Clock } from 'lucide-react';
import { useGetAccount, getGetAccountQueryKey } from '@workspace/api-client-react';
import { useAuth } from '@/lib/auth';
import { errMsg } from '@/lib/action';
import { PageHead } from '@/components/shell';
import { AuthNotice, EmptyArt, ErrorBox } from '@/components/notices';
import { Skeleton } from '@/components/ui/skeleton';
import { ago } from '@/components/post-card';
import { cn } from '@/lib/utils';

export default function MyAdsPage() {
  const { authed } = useAuth();
  const account = useGetAccount({ query: { queryKey: getGetAccountQueryKey(), enabled: authed, refetchInterval: 10_000 } });
  const ads = account.data?.ads ?? [];
  return (
    <div className="mx-auto max-w-4xl px-4 py-5 md:px-8 md:py-8">
      <PageHead kicker="Live counters · refreshed every 10s" title="My campaigns">
        <Link href="/chowk" className="rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground" data-testid="link-new-ad">
          New campaign
        </Link>
      </PageHead>
      {!authed ? (
        <AuthNotice what="see your campaigns" />
      ) : account.isLoading ? (
        <div className="space-y-3">{[0, 1].map((i) => <Skeleton key={i} className="h-36 rounded-3xl" />)}</div>
      ) : account.isError ? (
        <ErrorBox message={errMsg(account.error)} onRetry={() => void account.refetch()} />
      ) : ads.length === 0 ? (
        <EmptyArt title="No campaigns yet" body="Your shop's first poster on the Chowk is one form away.">
          <Link href="/chowk" className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground" data-testid="link-empty-chowk">
            Open Chowk
          </Link>
        </EmptyArt>
      ) : (
        <div className="space-y-4">
          {ads.map((a, i) => {
            const ctr = a.views > 0 ? ((a.clicks / a.views) * 100).toFixed(1) : null;
            return (
              <article key={a.id} className="rise overflow-hidden rounded-3xl border bg-card" style={{ animationDelay: `${i * 60}ms` }} data-testid={`card-ad-${a.id}`}>
                <div className="flex flex-wrap items-center gap-2 border-b p-4">
                  <h3 className="flex-1 font-display text-lg font-semibold">{a.title}</h3>
                  <span className={cn('rounded-full px-3 py-1 font-data text-[11px] uppercase tracking-wider', a.status === 'active' ? 'bg-secondary text-secondary-foreground' : 'bg-muted text-muted-foreground')} data-testid={`status-ad-${a.id}`}>
                    {a.status}
                  </span>
                  {a.simulated && <span className="rounded-full border border-dashed border-primary/40 px-2 py-0.5 font-data text-[10px] uppercase">Simulated payment</span>}
                </div>
                <div className="grid grid-cols-3 divide-x">
                  <div className="p-4">
                    <p className="flex items-center gap-1 text-xs text-muted-foreground"><Eye className="h-3.5 w-3.5" /> Views</p>
                    <p className="font-data text-2xl font-semibold" data-testid={`text-views-${a.id}`}>{a.views.toLocaleString('en-IN')}</p>
                  </div>
                  <div className="p-4">
                    <p className="flex items-center gap-1 text-xs text-muted-foreground"><MousePointerClick className="h-3.5 w-3.5" /> Clicks</p>
                    <p className="font-data text-2xl font-semibold" data-testid={`text-clicks-${a.id}`}>{a.clicks.toLocaleString('en-IN')}</p>
                  </div>
                  <div className="p-4">
                    <p className="text-xs text-muted-foreground">Click rate</p>
                    <p className="font-data text-2xl font-semibold">{ctr ? `${ctr}%` : '—'}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-1 bg-muted/50 px-4 py-2 text-xs text-muted-foreground">
                  <span>Rs {a.price.toLocaleString('en-IN')} · plan {a.planId}</span>
                  <span>Created {ago(a.createdAt)}</span>
                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{a.expiresAt ? `Ends ${ago(a.expiresAt)}` : 'Awaiting payment'}</span>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
