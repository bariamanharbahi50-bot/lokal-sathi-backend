import { useEffect, useRef, useState } from 'react';
import { Link } from 'wouter';
import { formatDistanceToNowStrict } from 'date-fns';
import { Heart, MessageSquareText, Send, Trash2, BadgeCheck, ExternalLink, MapPin, Loader2, Download } from 'lucide-react';
import type { Post } from '@workspace/api-client-react';
import { useAuth } from '@/lib/auth';
import { useAct, errMsg, categoryImage, categoryLabel, initials } from '@/lib/action';
import { useToast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { SampleTag } from './notices';
import { cn } from '@/lib/utils';

type Comment = { id: string; name: string; text: string; createdAt: string };

export function ago(iso: string) {
  try {
    return formatDistanceToNowStrict(new Date(iso), { addSuffix: true });
  } catch {
    return '';
  }
}

const viewed = new Set<string>();

export function CommentsDialog({ post, open, onOpenChange, onAdded }: { post: Post; open: boolean; onOpenChange: (o: boolean) => void; onAdded: () => void }) {
  const { act, pending } = useAct();
  const { toast } = useToast();
  const [list, setList] = useState<Comment[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [text, setText] = useState('');
  const load = async () => {
    setErr(null);
    try {
      const r = await act<Comment[]>('getComments', { id: post.id });
      setList(Array.isArray(r) ? r : []);
    } catch (e) {
      setErr(errMsg(e));
    }
  };
  const loadRef = useRef(load);
  loadRef.current = load;
  useEffect(() => {
    if (open) {
      setList(null);
      void loadRef.current();
    }
  }, [open, post.id]);
  const send = async () => {
    if (!text.trim()) return;
    try {
      await act('addComment', { id: post.id, text: text.trim() });
      setText('');
      onAdded();
      await load();
    } catch (e) {
      toast({ title: 'Comment not posted', description: errMsg(e), variant: 'destructive' });
    }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85dvh] overflow-hidden rounded-3xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Charcha</DialogTitle>
          <DialogDescription className="line-clamp-2">{post.caption}</DialogDescription>
        </DialogHeader>
        <div className="max-h-[45dvh] space-y-3 overflow-y-auto pr-1">
          {err && <p className="text-sm text-destructive">{err}</p>}
          {!list && !err && [0, 1, 2].map((i) => <Skeleton key={i} className="h-12 rounded-xl" />)}
          {list && list.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">No comments yet. Start the conversation.</p>}
          {list?.map((c) => (
            <div key={c.id} className="flex gap-3" data-testid={`comment-${c.id}`}>
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-accent text-xs font-semibold text-accent-foreground">{initials(c.name)}</AvatarFallback>
              </Avatar>
              <div className="rounded-2xl rounded-tl-sm bg-muted px-3 py-2 text-sm">
                <p className="font-semibold">
                  {c.name} <span className="font-normal text-muted-foreground">· {ago(c.createdAt)}</span>
                </p>
                <p>{c.text}</p>
              </div>
            </div>
          ))}
        </div>
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            void send();
          }}
        >
          <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="अपनी बात लिखें…" className="rounded-full" data-testid="input-comment" />
          <button type="submit" disabled={pending || !text.trim()} className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground disabled:opacity-50" data-testid="button-send-comment">
            {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function PostCard({ post, sample, ownId, onChanged, index = 0 }: { post: Post; sample?: boolean; ownId?: string | null; onChanged?: () => void; index?: number }) {
  const { authed } = useAuth();
  const { act } = useAct();
  const { toast } = useToast();
  const [liked, setLiked] = useState(post.liked);
  const [likes, setLikes] = useState(post.likes);
  const [comments, setComments] = useState(post.comments);
  const [popKey, setPopKey] = useState(0);
  const [showComments, setShowComments] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const [imgOk, setImgOk] = useState(true);
  const isOwn = !!ownId && post.authorId === ownId;
  const canAct = authed && !sample;

  useEffect(() => {
    if (post.isAd && canAct && !viewed.has(post.id)) {
      viewed.add(post.id);
      act('adEvent', { id: post.id, event: 'view' }).catch(() => undefined);
    }
  }, [post.id, post.isAd, canAct, act]);

  const like = async () => {
    if (!canAct) {
      toast({ title: sample ? 'This is sample content' : 'Sign in to like posts' });
      return;
    }
    const prev = { liked, likes };
    setLiked(!liked);
    setLikes(likes + (liked ? -1 : 1));
    setPopKey((k) => k + 1);
    try {
      const r = await act<{ liked: boolean }>('likePost', { id: post.id });
      if (typeof r?.liked === 'boolean' && r.liked !== !prev.liked) {
        setLiked(r.liked);
        setLikes(prev.likes + (r.liked ? 1 : 0) - (prev.liked ? 1 : 0));
      }
    } catch (e) {
      setLiked(prev.liked);
      setLikes(prev.likes);
      toast({ title: 'Could not like', description: errMsg(e), variant: 'destructive' });
    }
  };

  const del = async () => {
    try {
      const result = await act<{ mediaDeleted?: boolean; message?: string }>('deletePost', { id: post.id });
      setConfirmDel(false);
      onChanged?.();
      if (result.mediaDeleted === false && post.mediaType !== 'text') {
        toast({ title: 'Post deleted; media cleanup needs attention', description: result.message, variant: 'destructive' });
      } else {
        toast({ title: post.mediaType === 'text' ? 'Post deleted' : 'Post and media deleted' });
      }
    } catch (e) {
      toast({ title: 'Delete failed', description: errMsg(e), variant: 'destructive' });
    }
  };

  const openAd = () => {
    if (canAct) act('adEvent', { id: post.id, event: 'click' }).catch(() => undefined);
    if (post.targetUrl) window.open(post.targetUrl, '_blank', 'noopener');
  };

  const media = post.mediaType === 'text' ? null : imgOk && post.mediaUrl ? post.mediaUrl : categoryImage(post.category);

  return (
    <article
      className="rise overflow-hidden rounded-3xl border bg-card shadow-[0_18px_40px_-28px_hsl(232_60%_20%/.5)]"
      style={{ animationDelay: `${Math.min(index, 6) * 60}ms` }}
      data-testid={`card-post-${post.id}`}
    >
      <header className="flex items-center gap-3 p-4 pb-3">
        <Avatar className="h-10 w-10 ring-2 ring-accent ring-offset-2 ring-offset-card">
          {post.avatar && <AvatarImage src={post.avatar} alt="" />}
          <AvatarFallback className="bg-primary font-semibold text-primary-foreground">{initials(post.authorName)}</AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1 truncate font-semibold" data-testid={`text-author-${post.id}`}>
            {post.authorName}
            {post.verified && (
              <span title="Demo verification only — not an identity guarantee" className="inline-flex items-center gap-0.5 rounded-full bg-secondary/15 px-1.5 text-[10px] font-medium text-secondary">
                <BadgeCheck className="h-3 w-3" /> Verified (demo)
              </span>
            )}
          </p>
          <p className="flex items-center gap-1 truncate text-xs text-muted-foreground">
            <MapPin className="h-3 w-3" />
            {[post.area, post.city].filter(Boolean).join(', ')}
            {typeof post.distanceKm === 'number' && <span className="font-data">· {post.distanceKm.toFixed(1)} km</span>}
            <span>· {ago(post.createdAt)}</span>
          </p>
        </div>
        {post.isAd ? (
          <span className="rounded-full bg-accent px-2.5 py-1 font-data text-[10px] uppercase tracking-widest text-accent-foreground">Sponsored</span>
        ) : (
          <span className="rounded-full border px-2.5 py-1 text-[11px] text-muted-foreground">{categoryLabel(post.category)}</span>
        )}
      </header>

      {media && (
        <div className="relative aspect-[4/3] overflow-hidden bg-muted">
          {post.mediaType === 'video' && post.mediaUrl ? (
            <video src={post.mediaUrl} poster={post.posterUrl || categoryImage(post.category)} controls playsInline muted preload="metadata" className="h-full w-full object-cover" data-testid={`video-post-${post.id}`} />
          ) : (
            <img src={media} alt={post.caption} loading="lazy" onError={() => setImgOk(false)} className="h-full w-full object-cover transition-transform duration-700 hover:scale-[1.03]" />
          )}
          {sample && <SampleTag className="absolute left-3 top-3 bg-card/90" />}
        </div>
      )}
      {!media && (
        <div className="jaali relative mx-4 rounded-2xl border border-dashed border-primary/20 p-6">
          {sample && <SampleTag className="absolute right-3 top-3" />}
          <p className="font-display text-xl font-semibold leading-snug text-primary">{post.caption}</p>
        </div>
      )}

      <div className="p-4 pt-3">
        {media && <p className="mb-3 text-[15px] leading-relaxed" data-testid={`text-caption-${post.id}`}>{post.caption}</p>}
        {post.isAd && post.targetUrl && (
          <button onClick={openAd} data-testid={`button-ad-open-${post.id}`} className="mb-3 flex w-full items-center justify-between rounded-2xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground">
            Visit business <ExternalLink className="h-4 w-4" />
          </button>
        )}
        <div className="flex items-center gap-1">
          <button onClick={like} data-testid={`button-like-${post.id}`} className={cn('flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm transition-colors hover:bg-muted', liked && 'text-destructive')}>
            <Heart key={popKey} className={cn('h-5 w-5', popKey > 0 && 'pop', liked && 'fill-current')} />
            <span className="font-data">{likes}</span>
          </button>
          <button
            onClick={() => (canAct ? setShowComments(true) : toast({ title: sample ? 'This is sample content' : 'Sign in to join the charcha' }))}
            data-testid={`button-comments-${post.id}`}
            className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm hover:bg-muted"
          >
            <MessageSquareText className="h-5 w-5" />
            <span className="font-data">{comments}</span>
          </button>
          {canAct && !isOwn && (
            <Link
              href={`/messages?to=${encodeURIComponent(post.authorId)}&name=${encodeURIComponent(post.authorName)}`}
              data-testid={`link-message-${post.id}`}
              className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm hover:bg-muted"
            >
              <Send className="h-4 w-4" /> Message
            </Link>
          )}
          {canAct && isOwn && post.downloadUrl && (
            <a
              href={post.downloadUrl}
              download={`local-sathi-post-${post.id}.${post.mediaType === 'video' ? 'mp4' : 'jpg'}`}
              aria-label="Download your post media"
              data-testid={`button-download-${post.id}`}
              className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm hover:bg-muted"
            >
              <Download className="h-4 w-4" /> Download
            </a>
          )}
          {canAct && isOwn && (
            <button onClick={() => setConfirmDel(true)} data-testid={`button-delete-${post.id}`} className="ml-auto rounded-full p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive">
              <Trash2 className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
      {canAct && <CommentsDialog post={post} open={showComments} onOpenChange={setShowComments} onAdded={() => setComments((c) => c + 1)} />}
      <AlertDialog open={confirmDel} onOpenChange={setConfirmDel}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this post?</AlertDialogTitle>
            <AlertDialogDescription>It disappears for your neighbours and its photo or video is removed from Local Sathi storage. This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-full">Keep</AlertDialogCancel>
            <AlertDialogAction onClick={del} className="rounded-full bg-destructive text-destructive-foreground" data-testid="button-confirm-delete">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </article>
  );
}

export function PostSkeleton() {
  return (
    <div className="overflow-hidden rounded-3xl border bg-card">
      <div className="flex items-center gap-3 p-4">
        <Skeleton className="h-10 w-10 rounded-full" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-3 w-32" />
          <Skeleton className="h-3 w-48" />
        </div>
      </div>
      <Skeleton className="aspect-[4/3] rounded-none" />
      <div className="space-y-2 p-4">
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-2/3" />
      </div>
    </div>
  );
}
