import type { CapacitorConfig } from '@capacitor/cli';

const serverUrl = process.env.CAPACITOR_SERVER_URL?.trim();

if (serverUrl && !serverUrl.startsWith('https://')) {
  throw new Error('CAPACITOR_SERVER_URL must be an HTTPS URL.');
}

const config: CapacitorConfig = {
  appId: 'com.localsathi.app',
  appName: 'Local Sathi',
  webDir: 'dist/public',
  server: serverUrl
    ? {
        url: serverUrl,
        androidScheme: 'https',
        cleartext: false,
      }
    : undefined,
};

export default config;
