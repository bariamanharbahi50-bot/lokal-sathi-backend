import { useCallback, useEffect, useRef, useState } from 'react';
import { useSearch } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Send, Loader2, Lock } from 'lucide-react';
import { useGetAccount, getGetAccountQueryKey } from '@workspace/api-client-react';
import { useAuth } from '@/lib/auth';
import { useAct, errMsg, initials } from '@/lib/action';
import { PageHead } from '@/components/shell';
import { AuthNotice, EmptyArt, ErrorBox } from '@/components/notices';
import { Skeleton } from '@/components/ui/skeleton';
import { ago } from '@/components/post-card';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

type Msg = { id: string; senderId: string; text: string; createdAt: string };

function Thread({ userId, name, meId, onBack }: { userId: string; name: string; meId?: string; onBack: () => void }) {
  const { act, pending } = useAct();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [msgs, setMsgs] = useState<Msg[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [text, setText] = useState('');
  const endRef = useRef<HTMLDivElement>(null);
  const load = useCallback(async () => {
    try {
      const r = await act<Msg[]>('getMessages', { userId });
      setMsgs(Array.isArray(r) ? r : []);
      setErr(null);
    } catch (e) {
      setErr(errMsg(e));
    }
  }, [act, userId]);
  useEffect(() => {
    setMsgs(null);
    void load();
    const id = setInterval(() => void load(), 10_000);
    return () => clearInterval(id);
  }, [load]);
  const count = msgs?.length ?? 0;
  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [count]);
  const send = async () => {
    const t = text.trim();
    if (!t) return;
    try {
      await act('sendMessage', { userId, text: t });
      setText('');
      await load();
      void qc.invalidateQueries({ queryKey: getGetAccountQueryKey() });
    } catch (e) {
      toast({ title: 'Message not sent', description: errMsg(e), variant: 'destructive' });
    }
  };
  return (
    <div className="flex h-[calc(100dvh-11rem)] flex-col overflow-hidden rounded-3xl border bg-card md:h-[calc(100dvh-10rem)]">
      <div className="flex items-center gap-3 border-b p-3">
        <button onClick={onBack} className="rounded-full p-2 hover:bg-muted md:hidden" data-testid="button-thread-back"><ArrowLeft className="h-5 w-5" /></button>
        <span className="grid h-10 w-10 place-items-center rounded-full bg-accent font-semibold text-accent-foreground">{initials(name)}</span>
        <div className="flex-1">
          <p className="font-semibold" data-testid="text-thread-name">{name}</p>
          <p className="flex items-center gap-1 text-[11px] text-muted-foreground"><Lock className="h-3 w-3" /> Private · text only, no calls</p>
        </div>
      </div>
      <div className="jaali flex-1 space-y-2 overflow-y-auto p-4">
        {err && <ErrorBox message={err} onRetry={() => void load()} />}
        {!msgs && !err && [0, 1, 2].map((i) => <Skeleton key={i} className={cn('h-10 w-2/3 rounded-2xl', i % 2 && 'ml-auto')} />)}
        {msgs?.length === 0 && <p className="py-10 text-center text-sm text-muted-foreground">Say namaste to start the conversation.</p>}
        {msgs?.map((m) => {
          const mine = m.senderId === meId;
          return (
            <div key={m.id} className={cn('rise flex', mine ? 'justify-end' : 'justify-start')} data-testid={`msg-${m.id}`}>
              <div className={cn('max-w-[78%] rounded-2xl px-3.5 py-2 text-[15px] shadow-sm', mine ? 'rounded-br-sm bg-primary text-primary-foreground' : 'rounded-bl-sm bg-background')}>
                <p className="whitespace-pre-wrap break-words">{m.text}</p>
                <p className={cn('mt-0.5 text-right font-data text-[10px]', mine ? 'opacity-70' : 'text-muted-foreground')}>{ago(m.createdAt)}</p>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      <form className="flex gap-2 border-t p-3" onSubmit={(e) => { e.preventDefault(); void send(); }}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="संदेश लिखें… / સંદેશ લખો…" className="flex-1 rounded-full border bg-background px-4 py-2.5 text-sm outline-none focus:border-primary/50" data-testid="input-message" maxLength={1000} />
        <button type="submit" disabled={pending || !text.trim()} className="grid h-11 w-11 place-items-center rounded-full bg-destructive text-destructive-foreground transition active:scale-90 disabled:opacity-50" data-testid="button-send-message">
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </button>
      </form>
    </div>
  );
}

export default function MessagesPage() {
  const { authed } = useAuth();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const account = useGetAccount({ query: { queryKey: getGetAccountQueryKey(), enabled: authed, refetchInterval: 10_000 } });
  const [active, setActive] = useState<{ id: string; name: string } | null>(params.get('to') ? { id: params.get('to')!, name: params.get('name') || 'Neighbour' } : null);
  const convos = account.data?.conversations ?? [];

  if (!authed)
    return (
      <div className="mx-auto max-w-4xl px-4 py-5 md:px-8 md:py-8">
        <PageHead kicker="Baatcheet · बातचीत" title="Private chats" />
        <AuthNotice what="chat privately with neighbours" />
      </div>
    );

  return (
    <div className="mx-auto max-w-5xl px-4 py-5 md:px-8 md:py-8">
      <PageHead kicker="Baatcheet · बातचीत" title="Private chats" />
      <div className="grid gap-4 md:grid-cols-[300px_1fr]">
        <div className={cn('space-y-2', active && 'hidden md:block')}>
          {account.isLoading ? (
            [0, 1, 2].map((i) => <Skeleton key={i} className="h-16 rounded-2xl" />)
          ) : account.isError ? (
            <ErrorBox message={errMsg(account.error)} onRetry={() => void account.refetch()} />
          ) : convos.length === 0 && !active ? (
            <EmptyArt title="No chats yet" body="Tap Message on any neighbour's post to start a private conversation." />
          ) : (
            convos.map((c) => (
              <button key={c.id} onClick={() => setActive({ id: c.id, name: c.name })} data-testid={`button-convo-${c.id}`} className={cn('flex w-full items-center gap-3 rounded-2xl border p-3 text-left transition', active?.id === c.id ? 'border-primary bg-primary/5' : 'bg-card hover:border-primary/30')}>
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-secondary font-semibold text-secondary-foreground">{initials(c.name)}</span>
                <span className="min-w-0 flex-1">
                  <span className="flex justify-between gap-2"><span className="truncate font-semibold">{c.name}</span><span className="shrink-0 text-[11px] text-muted-foreground">{ago(c.updatedAt)}</span></span>
                  <span className="block truncate text-sm text-muted-foreground">{c.lastMessage}</span>
                </span>
              </button>
            ))
          )}
        </div>
        <div className={cn(!active && 'hidden md:block')}>
          {active ? (
            <Thread key={active.id} userId={active.id} name={active.name} meId={account.data?.profile.id} onBack={() => setActive(null)} />
          ) : (
            <EmptyArt title="Pick a conversation" body="Messages refresh every 10 seconds while this page is open." />
          )}
        </div>
      </div>
    </div>
  );
}
