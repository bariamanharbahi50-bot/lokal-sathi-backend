import { type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { Home, Clapperboard, Store, MessageCircle, Siren, UserRound, Megaphone, Wrench } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useGeo } from '@/lib/geo';
import { cn } from '@/lib/utils';

const NAV = [
  { href: '/', label: 'Mohalla', icon: Home },
  { href: '/reels', label: 'Reels', icon: Clapperboard },
  { href: '/chowk', label: 'Chowk', icon: Store },
  { href: '/messages', label: 'Chats', icon: MessageCircle },
  { href: '/sos', label: 'SOS', icon: Siren },
];
const EXTRA = [
  { href: '/my-ads', label: 'My Ads', icon: Megaphone },
  { href: '/profile', label: 'Profile', icon: UserRound },
  { href: '/setup', label: 'Setup', icon: Wrench },
];

export function Logo({ light }: { light?: boolean }) {
  return (
    <Link href="/" data-testid="link-home-logo" className="flex items-center gap-2">
      <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-accent">
        <span className="absolute h-4 w-4 rotate-45 rounded-sm border-2 border-primary" />
        <span className="h-1.5 w-1.5 rounded-full bg-destructive" />
      </span>
      <span className={cn('font-display text-xl font-extrabold leading-none', light ? 'text-sidebar-foreground' : 'text-primary')}>
        Local<span className="text-destructive">Sathi</span>
        <span className="block font-sans text-[10px] font-medium tracking-[0.2em] opacity-70">लोकल साथी</span>
      </span>
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const [loc] = useLocation();
  const { authed } = useAuth();
  const { alerts } = useGeo();
  const live = alerts.filter((a) => !a.isOwn).length;
  const immersive = loc === '/reels';
  const active = (h: string) => (h === '/' ? loc === '/' : loc.startsWith(h));

  return (
    <div className="min-h-[100dvh] bg-background">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col bg-sidebar p-5 text-sidebar-foreground md:flex">
        <Logo light />
        <div className="toran mt-5 opacity-80" />
        <nav className="mt-6 flex flex-col gap-1">
          {[...NAV, ...EXTRA].map((n) => (
            <Link
              key={n.href}
              href={n.href}
              data-testid={`link-nav-${n.label.toLowerCase().replace(/\s/g, '-')}`}
              className={cn(
                'group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[15px] transition-colors',
                active(n.href) ? 'bg-sidebar-primary font-semibold text-sidebar-primary-foreground' : 'hover:bg-sidebar-accent',
              )}
            >
              <n.icon className="h-[18px] w-[18px] transition-transform group-hover:-rotate-6" />
              {n.label}
              {n.href === '/sos' && live > 0 && (
                <span className="ml-auto rounded-full bg-destructive px-2 font-data text-xs text-destructive-foreground">{live}</span>
              )}
            </Link>
          ))}
        </nav>
        <div className="mt-auto rounded-2xl bg-sidebar-accent p-4 text-xs leading-relaxed opacity-90">
          <p className="font-display text-sm font-semibold">Pados ka saath.</p>
          <p className="mt-1 opacity-75">Shared location is encrypted in the database. For real emergencies always dial 112.</p>
          {!authed && (
            <Link href="/login" className="mt-3 inline-block font-semibold text-sidebar-primary" data-testid="link-sidebar-login">
              Sign in with Google
            </Link>
          )}
        </div>
      </aside>

      {!immersive && (
        <header className="sticky top-0 z-30 flex items-center justify-between border-b bg-background/85 px-4 py-3 backdrop-blur md:hidden">
          <Logo />
          <div className="flex items-center gap-2">
            <Link href="/my-ads" data-testid="link-mobile-myads" className="grid h-9 w-9 place-items-center rounded-full border bg-card">
              <Megaphone className="h-4 w-4" />
            </Link>
            <Link href="/profile" data-testid="link-mobile-profile" className="grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground">
              <UserRound className="h-4 w-4" />
            </Link>
          </div>
        </header>
      )}

      <main className={cn('md:pl-64', immersive ? '' : 'pb-24 md:pb-10')}>{children}</main>

      <nav className="fixed inset-x-3 bottom-3 z-40 flex justify-around rounded-2xl border bg-card/95 px-1 py-1.5 shadow-[0_10px_30px_-10px_hsl(232_60%_20%/.35)] backdrop-blur md:hidden">
        {NAV.map((n) => (
          <Link
            key={n.href}
            href={n.href}
            data-testid={`link-tab-${n.label.toLowerCase()}`}
            className={cn('relative flex flex-1 flex-col items-center gap-0.5 rounded-xl py-1.5 text-[11px] transition-all', active(n.href) ? 'text-primary' : 'text-muted-foreground')}
          >
            <span className={cn('grid h-8 w-12 place-items-center rounded-full transition-all', active(n.href) && (n.href === '/sos' ? 'bg-destructive text-destructive-foreground' : 'bg-accent text-accent-foreground'))}>
              <n.icon className="h-[18px] w-[18px]" />
            </span>
            {n.label}
            {n.href === '/sos' && live > 0 && <span className="absolute right-3 top-1 h-2.5 w-2.5 rounded-full bg-destructive ring-2 ring-card" />}
          </Link>
        ))}
      </nav>
    </div>
  );
}

export function PageHead({ kicker, title, children }: { kicker: string; title: string; children?: ReactNode }) {
  return (
    <div className="rise mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <p className="font-data text-[11px] uppercase tracking-[0.25em] text-secondary">{kicker}</p>
        <h1 className="font-display text-3xl font-extrabold leading-tight text-primary md:text-4xl">{title}</h1>
        <div className="rangoli-rule mt-2 w-28" />
      </div>
      {children}
    </div>
  );
}
