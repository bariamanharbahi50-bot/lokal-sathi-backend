package com.localsathi.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
